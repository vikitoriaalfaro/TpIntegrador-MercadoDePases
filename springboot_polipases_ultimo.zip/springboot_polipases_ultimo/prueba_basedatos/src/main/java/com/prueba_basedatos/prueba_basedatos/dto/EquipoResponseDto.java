package com.prueba_basedatos.prueba_basedatos.dto;

public class EquipoResponseDto {
    private Long id_equipo;
    private String nombre_equipo;
    private String nombre_liga;

    public EquipoResponseDto(Long id_equipo, String nombre_equipo, String nombre_liga) {
        this.id_equipo = id_equipo;
        this.nombre_equipo = nombre_equipo;
        this.nombre_liga = nombre_liga;
    }
    public EquipoResponseDto() {}

    public Long getId_equipo() {
        return id_equipo;
    }

    public void setId_equipo(Long id_equipo) {
        this.id_equipo = id_equipo;
    }

    public String getNombre_equipo() {
        return nombre_equipo;
    }

    public void setNombre_equipo(String nombre_equipo) {
        this.nombre_equipo = nombre_equipo;
    }

    public String getNombre_liga() {
        return nombre_liga;
    }

    public void setNombre_liga(String nombre_liga) {
        this.nombre_liga = nombre_liga;
    }
}
