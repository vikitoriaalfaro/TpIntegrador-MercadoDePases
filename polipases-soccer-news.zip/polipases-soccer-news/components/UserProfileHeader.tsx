import React from 'react';
import { SettingsIcon } from './Icons';

interface UserProfileHeaderProps {
  navigateToHome: () => void;
}

const UserProfileHeader: React.FC<UserProfileHeaderProps> = ({ navigateToHome }) => {
  const handleBackClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    navigateToHome();
  };

  return (
    <header className="flex items-center justify-between py-4">
      <img src="/polipases-logo.png" alt="PoliPases Logo" className="h-10" />
      <div className="flex items-center space-x-6">
        <a 
          href="#" 
          onClick={handleBackClick}
          className="text-gray-400 hover:text-white text-sm"
        >
          &laquo; Volver al inicio
        </a>
        <SettingsIcon />
      </div>
    </header>
  );
};

export default UserProfileHeader;