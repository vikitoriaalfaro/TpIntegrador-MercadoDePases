package com.prueba_basedatos.prueba_basedatos.model;

import jakarta.persistence.*;

import java.sql.Date;
import java.sql.Timestamp;

public class Fichaje {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_fichaje;

    @ManyToOne
    @JoinColumn(name = "jugador_idjugador")
    private Jugador jugador;

    @ManyToOne
    @JoinColumn(name = "equipo_idequipo_viejo")
    private Equipo equipo_viejo;
    @ManyToOne
    @JoinColumn(name = "equipo_idequipo_nuevo")
    private Equipo equipo_nuevo;

    private int num_camiseta;
    private int precio;
    private Timestamp fecha_hora;
    private Date duracion_contrato;

    public Fichaje(Long id_fichaje, Jugador jugador, Equipo equipo_viejo, Equipo equipo_nuevo, int num_camiseta, int precio, Timestamp fecha_hora, Date duracion_contrato) {
        this.id_fichaje = id_fichaje;
        this.jugador = jugador;
        this.equipo_viejo = equipo_viejo;
        this.equipo_nuevo = equipo_nuevo;
        this.num_camiseta = num_camiseta;
        this.precio = precio;
        this.fecha_hora = fecha_hora;
        this.duracion_contrato = duracion_contrato;
    }

    public Fichaje() {
    }

    public Long getId_fichaje() {
        return id_fichaje;
    }

    public void setId_fichaje(Long id_fichaje) {
        this.id_fichaje = id_fichaje;
    }

    public Jugador getJugador() {
        return jugador;
    }

    public void setJugador(Jugador jugador) {
        this.jugador = jugador;
    }

    public Equipo getEquipo_viejo() {
        return equipo_viejo;
    }

    public void setEquipo_viejo(Equipo equipo_viejo) {
        this.equipo_viejo = equipo_viejo;
    }

    public Equipo getEquipo_nuevo() {
        return equipo_nuevo;
    }

    public void setEquipo_nuevo(Equipo equipo_nuevo) {
        this.equipo_nuevo = equipo_nuevo;
    }

    public int getNum_camiseta() {
        return num_camiseta;
    }

    public void setNum_camiseta(int num_camiseta) {
        this.num_camiseta = num_camiseta;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public Timestamp getFecha_hora() {
        return fecha_hora;
    }

    public void setFecha_hora(Timestamp fecha_hora) {
        this.fecha_hora = fecha_hora;
    }

    public Date getDuracion_contrato() {
        return duracion_contrato;
    }

    public void setDuracion_contrato(Date duracion_contrato) {
        this.duracion_contrato = duracion_contrato;
    }
}
