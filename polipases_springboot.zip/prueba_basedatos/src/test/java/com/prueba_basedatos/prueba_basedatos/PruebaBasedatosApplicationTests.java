package com.prueba_basedatos.prueba_basedatos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaBasedatosApplicationTests {

	@Test
	void contextLoads() {
	}

}
