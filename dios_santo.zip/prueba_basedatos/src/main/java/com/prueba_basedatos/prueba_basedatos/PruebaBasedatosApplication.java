package com.prueba_basedatos.prueba_basedatos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

@SpringBootApplication
public class PruebaBasedatosApplication {


    public static void main(String[] args) {
		SpringApplication.run(PruebaBasedatosApplication.class, args);
	}

}
