import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.Socket;
import java.security.*;

public class Cliente {
    private static final String SERVER_ADDRESS = "172.16.2.13";
    private static final int SERVER_PORT = 5000;

    public static void main(String[] args) throws Exception {
        KeyPair clientKeyPair = generateRSAKeyPair();
        System.out.println("Cliente: par de claves generado.");

        Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);

        ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
        ObjectInputStream in = new ObjectInputStream(socket.getInputStream());

        out.writeObject(clientKeyPair.getPublic());
        out.flush();
        System.out.println("Cliente: clave pública enviada.");

        Object received = in.readObject();
        if (!(received instanceof ClavePublicaYRandomEncrypted)) {
            System.err.println("Cliente: no se recibió la clave esperada.");
            socket.close();
            return;
        }

        ClavePublicaYRandomEncrypted paquete = (ClavePublicaYRandomEncrypted) received;
        PublicKey serverPublicKey = paquete.getLlavePublica();

        boolean signatureOk = CryptoUtils.verify(paquete.getLlaveRandomEncriptada(), paquete.getSignature(), serverPublicKey);
        if (!signatureOk) {
            System.err.println("Cliente: firma inválida en paquete de clave AES. Abortando.");
            socket.close();
            return;
        }

        SecretKey clientLlaveRandom = desencriptarLlaveRandom(paquete.getLlaveRandomEncriptada(), clientKeyPair.getPrivate());
        System.out.println("Cliente: clave AES recibida y verificada.");

        JFrame frame = new JFrame("Cliente de imágenes");
        JPanel panel = new JPanel(new FlowLayout());
        JScrollPane scrollPane = new JScrollPane(panel);
        frame.add(scrollPane, BorderLayout.CENTER);

        JButton enviarBtn = new JButton("Enviar imagen");
        frame.add(enviarBtn, BorderLayout.SOUTH);

        frame.setSize(600, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        new Thread(() -> {
            try {
                while (true) {
                    Object obj = in.readObject();
                    if (obj instanceof ServerSignedImage ssi) {

                        boolean ok = CryptoUtils.verify(ssi.imageBytes, ssi.signature, serverPublicKey);
                        if (!ok) {
                            System.out.println("Cliente: firma inválida en imagen del servidor, descartando.");
                            continue;
                        }
                        ImageIcon originalIcon = new ImageIcon(ssi.imageBytes);
                        Image scaled = originalIcon.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH);
                        JLabel label = new JLabel(new ImageIcon(scaled));
                        panel.add(label);
                        panel.revalidate();
                        panel.repaint();
                    } else if (obj instanceof byte[]) {

                        byte[] imageBytes = (byte[]) obj;
                        ImageIcon originalIcon = new ImageIcon(imageBytes);
                        Image scaled = originalIcon.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH);
                        JLabel label = new JLabel(new ImageIcon(scaled));
                        panel.add(label);
                        panel.revalidate();
                        panel.repaint();
                    } else {
                        System.out.println("Cliente: recibido objeto tipo " + obj.getClass());
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();

        enviarBtn.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            if (chooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
                try {
                    File file = chooser.getSelectedFile();
                    byte[] imageBytes = readFileToBytes(file);

                    SecureRandom random = new SecureRandom();
                    byte[] iv = new byte[16];
                    random.nextBytes(iv);

                    byte[] encryptedImageBytes = getEncryptedImageBytes(iv, clientLlaveRandom, imageBytes);

                    byte[] signature = getSignature(iv, encryptedImageBytes, clientKeyPair);

                    EncryptedImage paquet = new EncryptedImage(iv, encryptedImageBytes, signature);
                    out.writeObject(paquet);
                    out.flush();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    private static byte[] getSignature(byte[] iv, byte[] encryptedImageBytes, KeyPair clientKeyPair) throws Exception {
        byte[] toSign = CryptoUtils.concat(iv, encryptedImageBytes);
        byte[] signature = CryptoUtils.sign(toSign, clientKeyPair.getPrivate());
        return signature;
    }

    private static byte[] getEncryptedImageBytes(byte[] iv, SecretKey clientLlaveRandom, byte[] imageBytes) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        IvParameterSpec ivSpec = new IvParameterSpec(iv);
        cipher.init(Cipher.ENCRYPT_MODE, clientLlaveRandom, ivSpec);
        byte[] encryptedImageBytes = cipher.doFinal(imageBytes);
        return encryptedImageBytes;
    }

    private static byte[] readFileToBytes(File file) throws IOException {
        FileInputStream fis = new FileInputStream(file);
        byte[] data = new byte[(int) file.length()];
        int read = 0;
        while (read < data.length) {
            int r = fis.read(data, read, data.length - read);
            if (r == -1) break;
            read += r;
        }
        fis.close();
        return data;
    }

    private static KeyPair generateRSAKeyPair() throws NoSuchAlgorithmException {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048);
        return keyGen.generateKeyPair();
    }

    private static SecretKey desencriptarLlaveRandom(byte[] llaveEncriptada, PrivateKey clavePrivadaCliente)
            throws Exception {
        Cipher decipher = Cipher.getInstance("RSA");
        decipher.init(Cipher.DECRYPT_MODE, clavePrivadaCliente);
        byte[] clientLlaveRandomByte = decipher.doFinal(llaveEncriptada);
        return new SecretKeySpec(clientLlaveRandomByte, "AES");
    }
}