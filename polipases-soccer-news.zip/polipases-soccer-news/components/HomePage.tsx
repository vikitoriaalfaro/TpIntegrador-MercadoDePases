    import React from 'react';
    import Header from './Header';
    import Hero from './Hero';
    import Leagues from './Leagues';
    import Transfers from './Transfers';
    import CreateXI from './CreateXI';
    import Rumors from './Rumors';

    interface HomePageProps {
    navigateToProfile: () => void;
    }

    const HomePage: React.FC<HomePageProps> = ({ navigateToProfile }) => {
    return (
        <>
        <Header navigateToProfile={navigateToProfile} />
        <main className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-4 space-y-8">
            <Hero />
            </div>
            <div className="lg:col-span-1">
            <Leagues />
            </div>
            <div className="lg:col-span-3 space-y-8">
            
            <Transfers />
            
            </div>
            <div className="lg:col-span-4 grid grid-cols-1 md:grid-cols-2 gap-8">
                <CreateXI />
                <Rumors />
            </div>
            
        </main>
        </>
    );
    };

    export default HomePage;
