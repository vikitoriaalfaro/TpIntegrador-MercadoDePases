package com.prueba_basedatos.prueba_basedatos.controller;

import com.prueba_basedatos.prueba_basedatos.model.*;
import com.prueba_basedatos.prueba_basedatos.repository.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.util.Map;

@RestController
@RequestMapping("/api/rumores")
@CrossOrigin(origins = "*")
public class RumorController {
    private final RumorRepository rumorRepository;
    private final JugadorRepository jugadorRepository;
    private final EquipoRepository equipoRepository;
    private final UserRepository userRepository;

    public RumorController(RumorRepository rumorRepository, JugadorRepository jugadorRepository, EquipoRepository equipoRepository, UserRepository userRepository) {
        this.rumorRepository = rumorRepository;
        this.jugadorRepository = jugadorRepository;
        this.equipoRepository = equipoRepository;
        this.userRepository = userRepository;
    }

    @PostMapping("/add")
    public ResponseEntity<String> addRumor(@RequestBody Map<String, Long> body) {
        Long idJugador = body.get("id_jugador");
        Long idEquipoViejo = body.get("id_equipo_viejo");
        Long idEquipoNuevo = body.get("id_equipo_nuevo");
        Long idUsuario = body.get("id_usuario");

        Jugador jugador = jugadorRepository.findById(idJugador)
                .orElseThrow(() -> new RuntimeException("Jugador no encontrado"));
        Equipo equipoViejo = equipoRepository.findById(idEquipoViejo)
                .orElseThrow(() -> new RuntimeException("Equipo viejo no encontrado"));
        Equipo equipoNuevo = equipoRepository.findById(idEquipoNuevo)
                .orElseThrow(() -> new RuntimeException("Equipo nuevo no encontrado"));
        Usuario usuario = userRepository.findById(idUsuario)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        Rumor nuevo = new Rumor();
        nuevo.setJugador(jugador);
        nuevo.setEquipo_viejo_rumor(equipoViejo);
        nuevo.setequipo_nuevo_rumor(equipoNuevo);
        nuevo.setUsuario_rumor(usuario);
        nuevo.setEs_correcto("POR_DEFINIR");
        nuevo.setValoracion(0);
        nuevo.setFecha_creacion(new java.sql.Date(System.currentTimeMillis()));

        rumorRepository.save(nuevo);
        return ResponseEntity.ok("Rumor registrado con éxito");
    }



}
