package com.prueba_basedatos.prueba_basedatos.model;

public class Rumor {
}
