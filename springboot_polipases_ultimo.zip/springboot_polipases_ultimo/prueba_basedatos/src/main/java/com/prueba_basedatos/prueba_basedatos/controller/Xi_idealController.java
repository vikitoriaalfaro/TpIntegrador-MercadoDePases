package com.prueba_basedatos.prueba_basedatos.controller;

import com.prueba_basedatos.prueba_basedatos.model.Jugador;
import com.prueba_basedatos.prueba_basedatos.model.Usuario;
import com.prueba_basedatos.prueba_basedatos.model.Xi_ideal;
import com.prueba_basedatos.prueba_basedatos.repository.JugadorRepository;
import com.prueba_basedatos.prueba_basedatos.repository.UserRepository;
import com.prueba_basedatos.prueba_basedatos.repository.Xi_idealRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/equipos-ideales")
public class Xi_idealController {

    private final Xi_idealRepository xi_idealRepository;
    private final JugadorRepository jugadorRepository;
    private final UserRepository userRepository;

    public Xi_idealController(Xi_idealRepository xi_idealRepository, JugadorRepository jugadorRepository, UserRepository userRepository) {
        this.xi_idealRepository = xi_idealRepository;
        this.jugadorRepository = jugadorRepository;
        this.userRepository = userRepository;
    }

    @PostMapping
    public ResponseEntity<String> ArmarEquipo(@RequestBody Map<String, Long> body){
        Long id_usuario = body.get("id_usuario");
        Long id_jugador1 = body.get("id_jugador1");
        Long id_jugador2 = body.get("id_jugador2");
        Long id_jugador3 = body.get("id_jugador3");
        Long id_jugador4 = body.get("id_jugador4");
        Long id_jugador5 = body.get("id_jugador5");
        Long id_jugador6 = body.get("id_jugador6");
        Long id_jugador7 = body.get("id_jugador7");
        Long id_jugador8 = body.get("id_jugador8");
        Long id_jugador9 = body.get("id_jugador9");
        Long id_jugador10 = body.get("id_jugador10");
        Long id_jugador11 = body.get("id_jugador11");

        Usuario usuario = userRepository.findById(id_usuario)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado")) ;
        Jugador jugador1 = jugadorRepository.findById(id_jugador1)
                .orElseThrow(() -> new RuntimeException("Jugador1 no encontrado"));
        Jugador jugador2 = jugadorRepository.findById(id_jugador2)
                .orElseThrow(() -> new RuntimeException("Jugador2 no encontrado"));
        Jugador jugador3 = jugadorRepository.findById(id_jugador3)
                .orElseThrow(() -> new RuntimeException("Jugador3 no encontrado"));
        Jugador jugador4 = jugadorRepository.findById(id_jugador4)
                .orElseThrow(() -> new RuntimeException("Jugador4 no encontrado"));
        Jugador jugador5 = jugadorRepository.findById(id_jugador5)
                .orElseThrow(() -> new RuntimeException("Jugador5 no encontrado"));
        Jugador jugador6 = jugadorRepository.findById(id_jugador6)
                .orElseThrow(() -> new RuntimeException("Jugador6 no encontrado"));
        Jugador jugador7 = jugadorRepository.findById(id_jugador7)
                .orElseThrow(() -> new RuntimeException("Jugador7 no encontrado"));
        Jugador jugador8 = jugadorRepository.findById(id_jugador8)
                .orElseThrow(() -> new RuntimeException("Jugador8 no encontrado"));
        Jugador jugador9 = jugadorRepository.findById(id_jugador9)
                .orElseThrow(() -> new RuntimeException("Jugador9 no encontrado"));
        Jugador jugador10 = jugadorRepository.findById(id_jugador10)
                .orElseThrow(() -> new RuntimeException("Jugador10 no encontrado"));
        Jugador jugador11 = jugadorRepository.findById(id_jugador11)
                .orElseThrow(() -> new RuntimeException("Jugador11 no encontrado"));

        Xi_ideal xi_ideal = new Xi_ideal(usuario,jugador1,jugador2,jugador3,jugador4,jugador5,jugador6,jugador7,jugador8,jugador9,jugador10,jugador11);

        xi_idealRepository.save(xi_ideal);
        return ResponseEntity.ok("Equipo ideal guardado correctamente");

    }

}
