
import React from 'react';
import { RumorIcon } from './Icons';

const Rumors: React.FC = () => {
  return (
    <div className="bg-[#2d2d2d] rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0 md:space-x-6">
      <div className="text-center md:text-left">
        <h2 className="text-xl font-bold mb-2">Rumores</h2>
        <p className="text-gray-400">Compartí y explorá los rumores de la comunidad.</p>
        <button className="mt-4 bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-lg transition duration-300">
          Crear rumor
        </button>
      </div>
      <RumorIcon />
    </div>
  );
};

export default Rumors;
