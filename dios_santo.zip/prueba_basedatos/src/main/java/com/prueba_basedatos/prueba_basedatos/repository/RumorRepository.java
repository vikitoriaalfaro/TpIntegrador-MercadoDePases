package com.prueba_basedatos.prueba_basedatos.repository;

import com.prueba_basedatos.prueba_basedatos.model.Rumor;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface RumorRepository extends JpaRepository<Rumor, Long> {

    @Transactional
    @Modifying
    @Query("UPDATE Rumor r SET r.valoracion = r.valoracion + 1 WHERE r.id_rumor = :id")
    void darLike(Long id);
}

