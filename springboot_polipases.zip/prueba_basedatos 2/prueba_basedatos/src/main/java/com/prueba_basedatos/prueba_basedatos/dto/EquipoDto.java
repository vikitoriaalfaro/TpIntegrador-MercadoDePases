package com.prueba_basedatos.prueba_basedatos.dto;

public class   EquipoDto {
    private String nombre_equipo;
    private String escudoBase64;
    private long liga_idliga;
    private String nombre_liga;
    private String estadio;

    public EquipoDto() {}

    public EquipoDto(String nombre_equipo, String escudoBase64, long liga_idliga, String nombre_liga,  String estadio) {
        this.nombre_equipo = nombre_equipo;
        this.escudoBase64 = escudoBase64;
        this.liga_idliga = liga_idliga;
        this.nombre_liga = nombre_liga;
        this.estadio = estadio;
    }


    public String getNombre_equipo() {
        return nombre_equipo;
    }

    public void setNombre_equipo(String nombre_equipo) {
        this.nombre_equipo = nombre_equipo;
    }

    public String getEscudoBase64() {
        return escudoBase64;
    }

    public String getEstadio() {
        return estadio;
    }

    public void setEstadio(String estadio) {
        this.estadio = estadio;
    }

    public void setEscudoBase64(String escudoBase64) {
        this.escudoBase64 = escudoBase64;
    }

    public long getLiga_idliga() {
        return liga_idliga;
    }

    public void setLiga_idliga(long liga_idliga) {
        this.liga_idliga = liga_idliga;
    }

    public String getNombre_liga() {
        return nombre_liga;
    }

    public void setNombre_liga(String nombre_liga) {
        this.nombre_liga = nombre_liga;
    }
}
