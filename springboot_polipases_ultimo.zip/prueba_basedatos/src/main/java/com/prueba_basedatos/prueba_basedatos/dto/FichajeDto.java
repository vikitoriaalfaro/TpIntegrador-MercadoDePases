package com.prueba_basedatos.prueba_basedatos.dto;

import java.sql.Date;
import java.sql.Timestamp;

public class FichajeDto {
    private Long id_fichaje;
    private String nombre_jugador;
    private String equipo_viejo;
    private String equipo_nuevo;
    private int num_camiseta;
    private int precio;
    private Timestamp fecha_hora;
    private Date duracion_contrato;

    public FichajeDto(Long id_fichaje, String nombre_jugador, String equipo_viejo,
                      String equipo_nuevo, int num_camiseta, int precio,
                      Timestamp fecha_hora, Date duracion_contrato) {
        this.id_fichaje = id_fichaje;
        this.nombre_jugador = nombre_jugador;
        this.equipo_viejo = equipo_viejo;
        this.equipo_nuevo = equipo_nuevo;
        this.num_camiseta = num_camiseta;
        this.precio = precio;
        this.fecha_hora = fecha_hora;
        this.duracion_contrato = duracion_contrato;
    }

    // Getters y Setters
    public Long getId_fichaje() { return id_fichaje; }
    public String getNombre_jugador() { return nombre_jugador; }
    public String getEquipo_viejo() { return equipo_viejo; }
    public String getEquipo_nuevo() { return equipo_nuevo; }
    public int getNum_camiseta() { return num_camiseta; }
    public int getPrecio() { return precio; }
    public Timestamp getFecha_hora() { return fecha_hora; }
    public Date getDuracion_contrato() { return duracion_contrato; }

    public void setId_fichaje(Long id_fichaje) { this.id_fichaje = id_fichaje; }
    public void setNombre_jugador(String nombre_jugador) { this.nombre_jugador = nombre_jugador; }
    public void setEquipo_viejo(String equipo_viejo) { this.equipo_viejo = equipo_viejo; }
    public void setEquipo_nuevo(String equipo_nuevo) { this.equipo_nuevo = equipo_nuevo; }
    public void setNum_camiseta(int num_camiseta) { this.num_camiseta = num_camiseta; }
    public void setPrecio(int precio) { this.precio = precio; }
    public void setFecha_hora(Timestamp fecha_hora) { this.fecha_hora = fecha_hora; }
    public void setDuracion_contrato(Date duracion_contrato) { this.duracion_contrato = duracion_contrato; }
}
