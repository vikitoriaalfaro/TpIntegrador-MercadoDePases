package com.prueba_basedatos.prueba_basedatos.dto;

public class EquipoDto {
    private long id_equipo; // 👈 agregar este campo
    private String nombre_equipo;
    private String escudo;
    private long liga_idliga;
    private String nombre_liga;
    private String estadio;

    public EquipoDto() {}

    public EquipoDto(long id_equipo, String nombre_equipo, String escudo,
                     long liga_idliga, String nombre_liga, String estadio) {
        this.id_equipo = id_equipo;
        this.nombre_equipo = nombre_equipo;
        this.escudo = escudo;
        this.liga_idliga = liga_idliga;
        this.nombre_liga = nombre_liga;
        this.estadio = estadio;
    }

    public long getId_equipo() { return id_equipo; }
    public void setId_equipo(long id_equipo) { this.id_equipo = id_equipo; }

    public String getNombre_equipo() {
        return nombre_equipo;
    }

    public void setNombre_equipo(String nombre_equipo) {
        this.nombre_equipo = nombre_equipo;
    }

    public String getescudo() {
        return escudo;
    }

    public void setescudo(String escudo) {
        this.escudo = escudo;
    }

    public long getLiga_idliga() {
        return liga_idliga;
    }

    public void setLiga_idliga(long liga_idliga) {
        this.liga_idliga = liga_idliga;
    }

    public String getNombre_liga() {
        return nombre_liga;
    }

    public void setNombre_liga(String nombre_liga) {
        this.nombre_liga = nombre_liga;
    }

    public String getEstadio() {
        return estadio;
    }

    public void setEstadio(String estadio) {
        this.estadio = estadio;
    }
}
