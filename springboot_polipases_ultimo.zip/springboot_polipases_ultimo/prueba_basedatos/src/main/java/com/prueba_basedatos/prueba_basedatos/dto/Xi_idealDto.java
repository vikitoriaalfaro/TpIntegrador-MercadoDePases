package com.prueba_basedatos.prueba_basedatos.dto;

import java.sql.Date;

public class Xi_idealDto {
    Long id_xi_ideal;
    Long usuario_id;
    Long jugador1_id;
    Long jugador2_id;
    Long jugador3_id;
    Long jugador4_id;
    Long jugador5_id;
    Long jugador6_id;
    Long jugador7_id;
    Long jugador8_id;
    Long jugador9_id;
    Long jugador10_id;
    Long jugador11_id;
    Date fecha_creacion;

    public Xi_idealDto(Long id_xi_ideal, Long usuario_id, Long jugador1_id, Long jugador2_id, Long jugador3_id, Long jugador4_id, Long jugador5_id, Long jugador6_id, Long jugador7_id, Long jugador8_id, Long jugador9_id, Long jugador10_id, Long jugador11_id, Date fecha_creacion) {
        this.id_xi_ideal = id_xi_ideal;
        this.usuario_id = usuario_id;
        this.jugador1_id = jugador1_id;
        this.jugador2_id = jugador2_id;
        this.jugador3_id = jugador3_id;
        this.jugador4_id = jugador4_id;
        this.jugador5_id = jugador5_id;
        this.jugador6_id = jugador6_id;
        this.jugador7_id = jugador7_id;
        this.jugador8_id = jugador8_id;
        this.jugador9_id = jugador9_id;
        this.jugador10_id = jugador10_id;
        this.jugador11_id = jugador11_id;
        this.fecha_creacion = new java.sql.Date(System.currentTimeMillis());
    }

    public Long getId_xi_ideal() {
        return id_xi_ideal;
    }

    public void setId_xi_ideal(Long id_xi_ideal) {
        this.id_xi_ideal = id_xi_ideal;
    }

    public Long getUsuario_id() {
        return usuario_id;
    }

    public void setUsuario_id(Long usuario_id) {
        this.usuario_id = usuario_id;
    }

    public Long getJugador1_id() {
        return jugador1_id;
    }

    public void setJugador1_id(Long jugador1_id) {
        this.jugador1_id = jugador1_id;
    }

    public Long getJugador2_id() {
        return jugador2_id;
    }

    public void setJugador2_id(Long jugador2_id) {
        this.jugador2_id = jugador2_id;
    }

    public Long getJugador3_id() {
        return jugador3_id;
    }

    public void setJugador3_id(Long jugador3_id) {
        this.jugador3_id = jugador3_id;
    }

    public Long getJugador4_id() {
        return jugador4_id;
    }

    public void setJugador4_id(Long jugador4_id) {
        this.jugador4_id = jugador4_id;
    }

    public Long getJugador5_id() {
        return jugador5_id;
    }

    public void setJugador5_id(Long jugador5_id) {
        this.jugador5_id = jugador5_id;
    }

    public Long getJugador6_id() {
        return jugador6_id;
    }

    public void setJugador6_id(Long jugador6_id) {
        this.jugador6_id = jugador6_id;
    }

    public Long getJugador7_id() {
        return jugador7_id;
    }

    public void setJugador7_id(Long jugador7_id) {
        this.jugador7_id = jugador7_id;
    }

    public Long getJugador8_id() {
        return jugador8_id;
    }

    public void setJugador8_id(Long jugador8_id) {
        this.jugador8_id = jugador8_id;
    }

    public Long getJugador9_id() {
        return jugador9_id;
    }

    public void setJugador9_id(Long jugador9_id) {
        this.jugador9_id = jugador9_id;
    }

    public Long getJugador10_id() {
        return jugador10_id;
    }

    public void setJugador10_id(Long jugador10_id) {
        this.jugador10_id = jugador10_id;
    }

    public Long getJugador11_id() {
        return jugador11_id;
    }

    public void setJugador11_id(Long jugador11_id) {
        this.jugador11_id = jugador11_id;
    }

    public Date getFecha_creacion() {
        return fecha_creacion;
    }

    public void setFecha_creacion(Date fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }
}
