import java.io.Serializable;

public class ServerSignedImage implements Serializable {
    private static final long serialVersionUID = 1L;
    public final byte[] imageBytes;
    public final byte[] signature;

    public ServerSignedImage(byte[] imageBytes, byte[] signature) {
        this.imageBytes = imageBytes;
        this.signature = signature;
    }
}
