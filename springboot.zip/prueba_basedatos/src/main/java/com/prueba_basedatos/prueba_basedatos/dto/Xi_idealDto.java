package com.prueba_basedatos.prueba_basedatos.dto;

import java.sql.Date;

public class Xi_idealDto {
    Long id_xi_ideal;
    Long usuario_id;
    String jugador1;
    String jugador1_imagen_url;
    String jugador2;
    String jugador2_imagen_url;
    String jugador3;
    String jugador3_imagen_url;
    String jugador4;
    String jugador4_imagen_url;
    String jugador5;
    String jugador5_imagen_url;
    String jugador6;
    String jugador6_imagen_url;
    String jugador7;
    String jugador7_imagen_url;
    String jugador8;
    String jugador8_imagen_url;
    String jugador9;
    String jugador9_imagen_url;
    String jugador10;
    String jugador10_imagen_url;
    String jugador11;
    String jugador11_imagen_url;
    Date fecha_creacion;

    public Xi_idealDto(Long id_xi_ideal, Long usuario_id, String jugador1, String jugador1_imagen_url, String jugador2, String jugador2_imagen_url, String jugador3, String jugador3_imagen_url, String jugador4, String jugador4_imagen_url, String jugador5, String jugador5_imagen_url, String jugador6, String jugador6_imagen_url, String jugador7, String jugador7_imagen_url, String jugador8, String jugador8_imagen_url, String jugador9, String jugador9_imagen_url, String jugador10, String jugador10_imagen_url, String jugador11, String jugador11_imagen_url, Date fecha_creacion) {
        this.id_xi_ideal = id_xi_ideal;
        this.usuario_id = usuario_id;
        this.jugador1 = jugador1;
        this.jugador1_imagen_url = jugador1_imagen_url;
        this.jugador2 = jugador2;
        this.jugador2_imagen_url = jugador2_imagen_url;
        this.jugador3 = jugador3;
        this.jugador3_imagen_url = jugador3_imagen_url;
        this.jugador4 = jugador4;
        this.jugador4_imagen_url = jugador4_imagen_url;
        this.jugador5 = jugador5;
        this.jugador5_imagen_url = jugador5_imagen_url;
        this.jugador6 = jugador6;
        this.jugador6_imagen_url = jugador6_imagen_url;
        this.jugador7 = jugador7;
        this.jugador7_imagen_url = jugador7_imagen_url;
        this.jugador8 = jugador8;
        this.jugador8_imagen_url = jugador8_imagen_url;
        this.jugador9 = jugador9;
        this.jugador9_imagen_url = jugador9_imagen_url;
        this.jugador10 = jugador10;
        this.jugador10_imagen_url = jugador10_imagen_url;
        this.jugador11 = jugador11;
        this.jugador11_imagen_url = jugador11_imagen_url;
        this.fecha_creacion = fecha_creacion;
    }

    public Xi_idealDto() {

    }

    public String getJugador1_imagen_url() {
        return jugador1_imagen_url;
    }

    public void setJugador1_imagen_url(String jugador1_imagen_url) {
        this.jugador1_imagen_url = jugador1_imagen_url;
    }

    public String getJugador2_imagen_url() {
        return jugador2_imagen_url;
    }

    public void setJugador2_imagen_url(String jugador2_imagen_url) {
        this.jugador2_imagen_url = jugador2_imagen_url;
    }

    public String getJugador3_imagen_url() {
        return jugador3_imagen_url;
    }

    public void setJugador3_imagen_url(String jugador3_imagen_url) {
        this.jugador3_imagen_url = jugador3_imagen_url;
    }

    public String getJugador4_imagen_url() {
        return jugador4_imagen_url;
    }

    public void setJugador4_imagen_url(String jugador4_imagen_url) {
        this.jugador4_imagen_url = jugador4_imagen_url;
    }

    public String getJugador5_imagen_url() {
        return jugador5_imagen_url;
    }

    public void setJugador5_imagen_url(String jugador5_imagen_url) {
        this.jugador5_imagen_url = jugador5_imagen_url;
    }

    public String getJugador6_imagen_url() {
        return jugador6_imagen_url;
    }

    public void setJugador6_imagen_url(String jugador6_imagen_url) {
        this.jugador6_imagen_url = jugador6_imagen_url;
    }

    public String getJugador7_imagen_url() {
        return jugador7_imagen_url;
    }

    public void setJugador7_imagen_url(String jugador7_imagen_url) {
        this.jugador7_imagen_url = jugador7_imagen_url;
    }

    public String getJugador8_imagen_url() {
        return jugador8_imagen_url;
    }

    public void setJugador8_imagen_url(String jugador8_imagen_url) {
        this.jugador8_imagen_url = jugador8_imagen_url;
    }

    public String getJugador9_imagen_url() {
        return jugador9_imagen_url;
    }

    public void setJugador9_imagen_url(String jugador9_imagen_url) {
        this.jugador9_imagen_url = jugador9_imagen_url;
    }

    public String getJugador10_imagen_url() {
        return jugador10_imagen_url;
    }

    public void setJugador10_imagen_url(String jugador10_imagen_url) {
        this.jugador10_imagen_url = jugador10_imagen_url;
    }

    public String getJugador11_imagen_url() {
        return jugador11_imagen_url;
    }

    public void setJugador11_imagen_url(String jugador11_imagen_url) {
        this.jugador11_imagen_url = jugador11_imagen_url;
    }

    public Long getId_xi_ideal() {
        return id_xi_ideal;
    }

    public void setId_xi_ideal(Long id_xi_ideal) {
        this.id_xi_ideal = id_xi_ideal;
    }

    public Long getUsuario_id() {
        return usuario_id;
    }

    public void setUsuario_id(Long usuario_id) {
        this.usuario_id = usuario_id;
    }

    public String getJugador1() {
        return jugador1;
    }

    public void setJugador1(String jugador1) {
        this.jugador1 = jugador1;
    }

    public String getJugador2() {
        return jugador2;
    }

    public void setJugador2(String jugador2) {
        this.jugador2 = jugador2;
    }

    public String getJugador3() {
        return jugador3;
    }

    public void setJugador3(String jugador3) {
        this.jugador3 = jugador3;
    }

    public String getJugador4() {
        return jugador4;
    }

    public void setJugador4(String jugador4) {
        this.jugador4 = jugador4;
    }

    public String getJugador5() {
        return jugador5;
    }

    public void setJugador5(String jugador5) {
        this.jugador5 = jugador5;
    }

    public String getJugador6() {
        return jugador6;
    }

    public void setJugador6(String jugador6) {
        this.jugador6 = jugador6;
    }

    public String getJugador7() {
        return jugador7;
    }

    public void setJugador7(String jugador7) {
        this.jugador7 = jugador7;
    }

    public String getJugador8() {
        return jugador8;
    }

    public void setJugador8(String jugador8) {
        this.jugador8 = jugador8;
    }

    public String getJugador9() {
        return jugador9;
    }

    public void setJugador9(String jugador9) {
        this.jugador9 = jugador9;
    }

    public String getJugador10() {
        return jugador10;
    }

    public void setJugador10(String jugador10) {
        this.jugador10 = jugador10;
    }

    public String getJugador11() {
        return jugador11;
    }

    public void setJugador11(String jugador11) {
        this.jugador11 = jugador11;
    }

    public Date getFecha_creacion() {
        return fecha_creacion;
    }

    public void setFecha_creacion(Date fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }
}
