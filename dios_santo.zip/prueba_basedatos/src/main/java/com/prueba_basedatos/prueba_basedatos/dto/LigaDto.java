package com.prueba_basedatos.prueba_basedatos.dto;

import java.time.LocalDate;

public class LigaDto {
    private String nombre_liga;
    private String pais_liga;
    private int division;
    private LocalDate inicio_mercado;
    private LocalDate fin_mercado;
    private String imagen_liga_url;

    public LigaDto() {}

    public LigaDto( String nombre_liga, String pais_liga, int division,
                   LocalDate inicio_mercado, LocalDate fin_mercado,  String imagen_liga_url) {
        this.nombre_liga = nombre_liga;
        this.pais_liga = pais_liga;
        this.division = division;
        this.inicio_mercado = inicio_mercado;
        this.fin_mercado = fin_mercado;
        this.imagen_liga_url = imagen_liga_url;
    }


    public String getNombre_liga() {
        return nombre_liga;
    }

    public String getImagen_liga_url() {
        return imagen_liga_url;
    }

    public void setImagen_liga_url(String imagen_liga_url) {
        this.imagen_liga_url = imagen_liga_url;
    }

    public void setNombre_liga(String nombre_liga) {
        this.nombre_liga = nombre_liga;
    }

    public String getPais_liga() {
        return pais_liga;
    }

    public void setPais_liga(String pais_liga) {
        this.pais_liga = pais_liga;
    }

    public int getDivision() {
        return division;
    }

    public void setDivision(int division) {
        this.division = division;
    }

    public LocalDate getInicio_mercado() {
        return inicio_mercado;
    }

    public void setInicio_mercado(LocalDate inicio_mercado) {
        this.inicio_mercado = inicio_mercado;
    }

    public LocalDate getFin_mercado() {
        return fin_mercado;
    }

    public void setFin_mercado(LocalDate fin_mercado) {
        this.fin_mercado = fin_mercado;
    }
}

