package com.prueba_basedatos.prueba_basedatos.dto;

public class UsuarioDto {
    private String nombre_usuario;
    private String mail;
    private int puntos;
    private long usuario_id;
    private String foto_usuario_url;


    public UsuarioDto(String nombre_usuario, String mail, int puntos, long usuarioId, String fotoUsuarioUrl) {
        this.nombre_usuario = nombre_usuario;
        this.mail = mail;
        this.puntos = puntos;
        this.usuario_id = usuarioId;
        this.foto_usuario_url = fotoUsuarioUrl;
    }

    public String getNombre_usuario() {
        return nombre_usuario;
    }

    public void setNombre_usuario(String nombre_usuario) {
        this.nombre_usuario = nombre_usuario;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public long getUsuario_id() {
        return usuario_id;
    }

    public void setUsuario_id(long usuario_id) {
        this.usuario_id = usuario_id;
    }

    public String getFoto_usuario_url() {
        return foto_usuario_url;
    }

    public void setFoto_usuario_url(String foto_usuario_url) {
        this.foto_usuario_url = foto_usuario_url;
    }
}
