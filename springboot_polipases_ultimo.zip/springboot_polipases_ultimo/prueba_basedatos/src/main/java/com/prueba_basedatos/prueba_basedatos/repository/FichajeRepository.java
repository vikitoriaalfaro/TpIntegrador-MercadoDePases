package com.prueba_basedatos.prueba_basedatos.repository;

import com.prueba_basedatos.prueba_basedatos.model.Fichaje;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FichajeRepository extends JpaRepository<Fichaje, Long> {
}

