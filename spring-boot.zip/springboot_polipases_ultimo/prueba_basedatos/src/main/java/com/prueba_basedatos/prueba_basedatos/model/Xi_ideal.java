package com.prueba_basedatos.prueba_basedatos.model;

import jakarta.persistence.*;

import java.sql.Date;

@Entity
@Table(name = "xi_ideal")
public class Xi_ideal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_xi_ideal;

    @OneToOne
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;

    @ManyToOne
    @JoinColumn(name = "id_jugador1")
    private Jugador jugador1;

    @ManyToOne
    @JoinColumn(name = "id_jugador2")
    private Jugador jugador2;

    @ManyToOne
    @JoinColumn(name = "id_jugador3")
    private Jugador jugador3;

    @ManyToOne
    @JoinColumn(name = "id_jugador4")
    private Jugador jugador4;

    @ManyToOne
    @JoinColumn(name = "id_jugador5")
    private Jugador jugador5;

    @ManyToOne
    @JoinColumn(name = "id_jugador6")
    private Jugador jugador6;

    @ManyToOne
    @JoinColumn(name = "id_jugador7")
    private Jugador jugador7;

    @ManyToOne
    @JoinColumn(name = "id_jugador8")
    private Jugador jugador8;


    @ManyToOne
    @JoinColumn(name = "id_jugador9")
    private Jugador jugador9;

    @ManyToOne
    @JoinColumn(name = "id_jugador10")
    private Jugador jugador10;

    @ManyToOne
    @JoinColumn(name = "id_jugador11")
    private Jugador jugador11;

    private Date fecha_creacion;

    public Xi_ideal(Usuario usuario, Jugador jugador1, Jugador jugador2, Jugador jugador3, Jugador jugador4, Jugador jugador5, Jugador jugador6, Jugador jugador7, Jugador jugador8, Jugador jugador9, Jugador jugador10, Jugador jugador11) {
        this.usuario = usuario;
        this.jugador1 = jugador1;
        this.jugador2 = jugador2;
        this.jugador3 = jugador3;
        this.jugador4 = jugador4;
        this.jugador5 = jugador5;
        this.jugador6 = jugador6;
        this.jugador7 = jugador7;
        this.jugador8 = jugador8;
        this.jugador9 = jugador9;
        this.jugador10 = jugador10;
        this.jugador11 = jugador11;
        this.fecha_creacion = new java.sql.Date(System.currentTimeMillis());
    }

    public Xi_ideal() {
    }

    public Long getId_xi_ideal() {
        return id_xi_ideal;
    }

    public void setId_xi_ideal(Long id_xi_ideal) {
        this.id_xi_ideal = id_xi_ideal;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Jugador getJugador1() {
        return jugador1;
    }

    public void setJugador1(Jugador jugador1) {
        this.jugador1 = jugador1;
    }

    public Jugador getJugador2() {
        return jugador2;
    }

    public void setJugador2(Jugador jugador2) {
        this.jugador2 = jugador2;
    }

    public Jugador getJugador3() {
        return jugador3;
    }

    public void setJugador3(Jugador jugador3) {
        this.jugador3 = jugador3;
    }

    public Jugador getJugador4() {
        return jugador4;
    }

    public void setJugador4(Jugador jugador4) {
        this.jugador4 = jugador4;
    }

    public Jugador getJugador5() {
        return jugador5;
    }

    public void setJugador5(Jugador jugador5) {
        this.jugador5 = jugador5;
    }

    public Jugador getJugador6() {
        return jugador6;
    }

    public void setJugador6(Jugador jugador6) {
        this.jugador6 = jugador6;
    }

    public Jugador getJugador7() {
        return jugador7;
    }

    public void setJugador7(Jugador jugador7) {
        this.jugador7 = jugador7;
    }

    public Jugador getJugador8() {
        return jugador8;
    }

    public void setJugador8(Jugador jugador8) {
        this.jugador8 = jugador8;
    }

    public Jugador getJugador9() {
        return jugador9;
    }

    public void setJugador9(Jugador jugador9) {
        this.jugador9 = jugador9;
    }

    public Jugador getJugador10() {
        return jugador10;
    }

    public void setJugador10(Jugador jugador10) {
        this.jugador10 = jugador10;
    }

    public Jugador getJugador11() {
        return jugador11;
    }

    public void setJugador11(Jugador jugador11) {
        this.jugador11 = jugador11;
    }

    public Date getFecha_creacion() {
        return fecha_creacion;
    }

    public void setFecha_creacion(Date fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }
}
