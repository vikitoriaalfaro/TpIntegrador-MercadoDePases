import React, { useState, useEffect } from 'react';
import type { ApiTransfer } from '../types';
import { ArrowRightIcon } from './Icons';

const API_BASE_URL = 'http://localhost:8080';

// Helper function to format the date string (YYYY-MM-DDTHH:mm:ss) to just the date part.
const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleDateString('es-ES', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });
};

// Helper function to format the price into a currency string.
const formatPrice = (price: number) => {
    if (price === 0) return 'Gratis';
    return new Intl.NumberFormat('es-ES', {
        style: 'currency',
        currency: 'EUR',
        minimumFractionDigits: 0,
    }).format(price);
}

const TransferCard: React.FC<{ transfer: ApiTransfer }> = ({ transfer }) => {
  // CORRECTED: Added the /api prefix to match the backend controller's @RequestMapping
  const playerImageUrl = transfer.jugador_imagen_url ? `${API_BASE_URL}/api${transfer.jugador_imagen_url}` : null;
  const teamLogoUrl = transfer.equipo_nuevo_imagen_url ? `${API_BASE_URL}/api${transfer.equipo_nuevo_imagen_url}` : null;
  
  return (
    <div className="bg-[#2d2d2d] rounded-2xl p-4 flex flex-col space-y-3 border border-gray-700/50">
      {/* Top Section: Player Name, Position, Price */}
      <div className="flex justify-between items-start">
          <div>
              <h3 className="font-bold text-lg">{transfer.nombre_jugador}</h3>
              <p className="text-sm text-gray-400">Camiseta #{transfer.num_camiseta}</p>
          </div>
          <div className="text-right">
              <p className="font-bold text-green-500 text-lg">{formatPrice(transfer.precio)}</p>
              <p className="text-xs text-gray-400">Hasta: {formatDate(transfer.duracion_contrato)}</p>
          </div>
      </div>

      {/* Middle Section: Images and Arrow */}
      <div className="flex items-center justify-between space-x-2 text-center py-2">
          <div className="flex flex-col items-center w-1/3 space-y-1">
              {playerImageUrl ? (
                <img
                    src={playerImageUrl}
                    alt={transfer.nombre_jugador}
                    className="w-16 h-16 rounded-full object-cover mb-1 border-2 border-gray-600"
                />
              ) : (
                <div className="w-16 h-16 rounded-full bg-gray-500 flex items-center justify-center mb-1 border-2 border-gray-600">
                  <span className="text-3xl text-gray-400">?</span>
                </div>
              )}
              <span className="font-semibold text-gray-300 w-full truncate">{transfer.equipo_viejo}</span>
          </div>

          <ArrowRightIcon />

          <div className="flex flex-col items-center w-1/3 space-y-1">
              {teamLogoUrl ? (
                <img
                    src={teamLogoUrl}
                    alt={transfer.equipo_nuevo}
                    className="w-16 h-16 object-contain mb-1"
                />
              ) : (
                <div className="w-16 h-16 bg-gray-500 flex items-center justify-center mb-1">
                  <span className="text-3xl text-gray-400">?</span>
                </div>
              )}
              <span className="font-bold text-white w-full truncate">{transfer.equipo_nuevo}</span>
          </div>
      </div>
    </div>
  );
};

const Transfers: React.FC = () => {
  const [transfers, setTransfers] = useState<ApiTransfer[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchTransfers = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/fichajes`);
        if (!response.ok) {
          throw new Error('No se pudieron obtener los datos de fichajes');
        }
        const allTransfers: ApiTransfer[] = await response.json();

        // 1. Filter transfers from the last week
        const oneWeekAgo = new Date();
        oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

        const recentTransfers = allTransfers.filter(t => new Date(t.fecha_hora) >= oneWeekAgo);
        
        // 2. Shuffle the recent transfers array
        const shuffled = recentTransfers.sort(() => 0.5 - Math.random());

        // 3. Get the first 3 elements
        setTransfers(shuffled.slice(0, 3));

      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchTransfers();
  }, []);

  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Novedades</h2>
      <div className="space-y-4">
        {loading && <p className="text-center text-gray-400">Cargando novedades...</p>}
        {error && <p className="text-center text-red-500">Error: {error}</p>}
        {!loading && !error && transfers.length > 0 && transfers.map((transfer) => (
          <TransferCard key={transfer.id_fichaje} transfer={transfer} />
        ))}
        {!loading && !error && transfers.length === 0 && (
            <p className="text-center text-gray-400 bg-[#2d2d2d] rounded-2xl p-4">No hay fichajes recientes en la última semana.</p>
        )}
      </div>
    </div>
  );
};

export default Transfers;