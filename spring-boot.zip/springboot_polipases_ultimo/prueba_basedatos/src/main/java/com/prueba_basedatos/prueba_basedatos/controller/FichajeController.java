package com.prueba_basedatos.prueba_basedatos.controller;

import com.prueba_basedatos.prueba_basedatos.dto.FichajeDto;
import com.prueba_basedatos.prueba_basedatos.model.Equipo;
import com.prueba_basedatos.prueba_basedatos.model.Fichaje;
import com.prueba_basedatos.prueba_basedatos.model.Jugador;
import com.prueba_basedatos.prueba_basedatos.repository.EquipoRepository;
import com.prueba_basedatos.prueba_basedatos.repository.FichajeRepository;
import com.prueba_basedatos.prueba_basedatos.repository.JugadorRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/fichajes")
@CrossOrigin(origins = "*")
public class FichajeController {

    private final FichajeRepository fichajeRepository;
    private final JugadorRepository jugadorRepository;
    private final EquipoRepository equipoRepository;

    public FichajeController(FichajeRepository fichajeRepository,
                             JugadorRepository jugadorRepository,
                             EquipoRepository equipoRepository) {
        this.fichajeRepository = fichajeRepository;
        this.jugadorRepository = jugadorRepository;
        this.equipoRepository = equipoRepository;
    }

    // ✅ Crear un fichaje
    @PostMapping("/add")
    public ResponseEntity<String> addFichaje(@RequestBody Fichaje nuevo) {
        // Validar jugador
        Jugador jugador = jugadorRepository.findById(nuevo.getJugador().getId_jugador())
                .orElseThrow(() -> new RuntimeException("Jugador no encontrado"));

        // Validar equipos
        Equipo equipoViejo = equipoRepository.findById(nuevo.getEquipo_viejo().getId_equipo())
                .orElseThrow(() -> new RuntimeException("Equipo viejo no encontrado"));

        Equipo equipoNuevo = equipoRepository.findById(nuevo.getEquipo_nuevo().getId_equipo())
                .orElseThrow(() -> new RuntimeException("Equipo nuevo no encontrado"));

        nuevo.setJugador(jugador);
        nuevo.setEquipo_viejo(equipoViejo);
        nuevo.setEquipo_nuevo(equipoNuevo);

        fichajeRepository.save(nuevo);
        return ResponseEntity.ok("Fichaje registrado con éxito");
    }

    // ✅ Obtener todos los fichajes
    @GetMapping
    public ResponseEntity<List<FichajeDto>> getAllFichajes() {
        List<FichajeDto> fichajes = fichajeRepository.findAll().stream()
                .map(f -> new FichajeDto(
                        f.getId_fichaje(),
                        f.getJugador() != null
                                ? f.getJugador().getNombre_jugador() + " " + f.getJugador().getApellido()
                                : "Desconocido",
                        f.getEquipo_viejo() != null ? f.getEquipo_viejo().getNombre_equipo() : "Sin equipo",
                        f.getEquipo_nuevo() != null ? f.getEquipo_nuevo().getNombre_equipo() : "Sin equipo",
                        f.getNum_camiseta(),
                        f.getPrecio(),
                        f.getFecha_hora(),
                        f.getDuracion_contrato(),
                        "/equipos/" + f.getEquipo_nuevo().getId_equipo() + "/imagen",
                        "/jugadores/" + f.getJugador().getId_jugador() + "/imagen"
                ))
                .toList();

        return ResponseEntity.ok(fichajes);
    }
}

