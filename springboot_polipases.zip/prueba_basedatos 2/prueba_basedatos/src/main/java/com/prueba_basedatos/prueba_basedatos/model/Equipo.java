package com.prueba_basedatos.prueba_basedatos.model;

import jakarta.persistence.*;

@Entity
@Table(name = "Equipo")
public class Equipo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_equipo;

    private String nombre_equipo;

    @Lob
    @Column(columnDefinition = "MEDIUMBLOB")
    private byte[] escudo;

    @ManyToOne
    @JoinColumn(name = "liga_idliga")
    private Liga liga;

    private String estadio;

    // Getters y setters
    public Long getId_equipo() { return id_equipo; }
    public void setId_equipo(Long id_equipo) { this.id_equipo = id_equipo; }

    public String getNombre_equipo() { return nombre_equipo; }
    public void setNombre_equipo(String nombre_equipo) { this.nombre_equipo = nombre_equipo; }

    public byte[] getEscudo() { return escudo; }
    public void setEscudo(byte[] escudo) { this.escudo = escudo; }

    public Liga getLiga() { return liga; }
    public void setLiga(Liga liga) { this.liga = liga; }

    public String getEstadio() {
        return estadio;
    }

    public void setEstadio(String estadio) {
        this.estadio = estadio;
    }
}
