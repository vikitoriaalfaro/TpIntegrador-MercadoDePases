import type React from 'react';

// This interface now uses camelCase to match Spring Boot's default JSON output.
export interface ApiLeague {
  nombreLiga: string;
  imagenUrl: string;
}

// This interface now uses snake_case to perfectly match the FichajeDto
// from your Spring Boot backend.
export interface ApiTransfer {
  id_fichaje: number;
  nombre_jugador: string;
  equipo_viejo: string;
  equipo_nuevo: string;
  num_camiseta: number;
  precio: number;
  fecha_hora: string;
  duracion_contrato: string;
  equipo_nuevo_imagen_url?: string;
  jugador_imagen_url?: string;
}


// Corresponds to the NoticiaDto from your backend, now using camelCase
export interface ApiNoticias {
  titulo: string;
  imagenNoticiaUrl: string;
}