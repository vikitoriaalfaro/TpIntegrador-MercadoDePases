package com.prueba_basedatos.prueba_basedatos.repository;

import com.prueba_basedatos.prueba_basedatos.model.Rumor;
import com.prueba_basedatos.prueba_basedatos.model.Xi_ideal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface Xi_idealRepository extends JpaRepository<Xi_ideal, Long> {

    @Query("SELECT r FROM Xi_ideal r WHERE r.usuario.id_usuario = :id")
    Xi_ideal findByUsuarioId(@Param("id") Long id);
}
