package com.prueba_basedatos.prueba_basedatos.controller;

import com.prueba_basedatos.prueba_basedatos.model.*;
import com.prueba_basedatos.prueba_basedatos.repository.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;

@RestController
@RequestMapping("/api/rumores")
@CrossOrigin(origins = "*")
public class RumorController {
    private final RumorRepository rumorRepository;
    private final JugadorRepository jugadorRepository;
    private final EquipoRepository equipoRepository;
    private final UserRepository userRepository;

    public RumorController(RumorRepository rumorRepository, JugadorRepository jugadorRepository, EquipoRepository equipoRepository, UserRepository userRepository) {
        this.rumorRepository = rumorRepository;
        this.jugadorRepository = jugadorRepository;
        this.equipoRepository = equipoRepository;
        this.userRepository = userRepository;
    }

    @PostMapping("/add")
    public ResponseEntity<String> addRumor(@RequestBody Rumor nuevo) {
        // Validar jugador
        Jugador jugador = jugadorRepository.findById(nuevo.getJugador().getId_jugador())
                .orElseThrow(() -> new RuntimeException("Jugador no encontrado"));

        // Validar equipos
        Equipo equipoViejo = equipoRepository.findById(nuevo.getEquipo_viejo_rumor().getId_equipo())
                .orElseThrow(() -> new RuntimeException("Equipo viejo no encontrado"));

        Equipo equipoNuevo = equipoRepository.findById(nuevo.getequipo_nuevo_rumor().getId_equipo())
                .orElseThrow(() -> new RuntimeException("Equipo nuevo no encontrado"));

        Usuario usuarioNuevo =userRepository.findById(nuevo.getUsuario_rumor().getId_usuario())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        nuevo.setJugador(jugador);
        nuevo.setEquipo_viejo_rumor(equipoViejo);
        nuevo.setequipo_nuevo_rumor(equipoNuevo);
        nuevo.setUsuario_rumor(usuarioNuevo);
        nuevo.setEs_correcto("POR_DEFINIR");
        java.util.Date utilDate = new java.util.Date();
        java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
        nuevo.setFecha_creacion(sqlDate);
        nuevo.setValoracion(0);
        rumorRepository.save(nuevo);
        return ResponseEntity.ok("Rumor registrado con éxito");
    }


}
