package com.prueba_basedatos.prueba_basedatos.controller;

import com.prueba_basedatos.prueba_basedatos.dto.JugadorDto;
import com.prueba_basedatos.prueba_basedatos.model.Equipo;
import com.prueba_basedatos.prueba_basedatos.model.Jugador;
import com.prueba_basedatos.prueba_basedatos.model.Liga;
import com.prueba_basedatos.prueba_basedatos.model.Usuario;
import com.prueba_basedatos.prueba_basedatos.repository.JugadorRepository;
import com.prueba_basedatos.prueba_basedatos.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/jugadores")
public class JugadorController {

    private final JugadorRepository jugadorRepository;

    public JugadorController(JugadorRepository jugadorRepository) {
        this.jugadorRepository = jugadorRepository;
    }

    @PostMapping("/add")
    public ResponseEntity<String> addJugador(@RequestBody Jugador jugador) {
        jugadorRepository.save(jugador);
        return ResponseEntity.ok("Jugador guardado con éxito");
    }

    @GetMapping("/{id}/imagen")
    public ResponseEntity<byte[]> getImagenJugador(@PathVariable Long id) {
        Jugador jugador = jugadorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Jugador no encontrado"));

        byte[] imagen = jugador.getimagen_jugador();
        return ResponseEntity
                .ok()
                .header("Content-Type", "image/png")
                .body(imagen);
    }

    @GetMapping
    public ResponseEntity<List<JugadorDto>> getAllJugadores() {
        List<JugadorDto> jugadores = jugadorRepository.findAll()
                .stream()
                .map(j -> new JugadorDto(
                        j.getNombre_jugador(),
                        j.getApellido(),
                        j.getNacionalidad(),
                        j.getAltura(),
                        j.getPeso(),
                        j.getValor_mercado(),
                        j.getF_nacimiento(),
                        j.getPosicion(),
                        j.getSueldo(),
                        j.getEquipo(),
                        j.getEquipo().getNombre_equipo(),
                        "/jugadores/" + j.getId_jugador() + "/imagen"
                ))
                .toList();

        return ResponseEntity.ok(jugadores);
    }
}
