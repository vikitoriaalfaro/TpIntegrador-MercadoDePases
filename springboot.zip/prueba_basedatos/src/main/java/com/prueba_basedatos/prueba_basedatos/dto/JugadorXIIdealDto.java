package com.prueba_basedatos.prueba_basedatos.dto;

public class JugadorXIIdealDto {
    private Long id;
    private String nombre;
    private String apellido;
    private String imagen_url;

    public JugadorXIIdealDto(Long id, String nombre, String apellido, String imagen_url) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.imagen_url = imagen_url;
    }

    public JugadorXIIdealDto() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getImagen_url() {
        return imagen_url;
    }

    public void setImagen_url(String imagen_url) {
        this.imagen_url = imagen_url;
    }
}
