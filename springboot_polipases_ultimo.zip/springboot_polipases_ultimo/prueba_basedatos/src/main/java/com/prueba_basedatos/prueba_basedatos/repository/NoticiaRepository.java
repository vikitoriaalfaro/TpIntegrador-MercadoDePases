package com.prueba_basedatos.prueba_basedatos.repository;

import com.prueba_basedatos.prueba_basedatos.model.Noticia;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NoticiaRepository extends JpaRepository<Noticia, Long> {
}
