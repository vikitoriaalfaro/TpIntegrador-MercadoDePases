import React from 'react';
import { AtSymbolIcon, InstagramIcon, XIcon } from './Icons';

const Footer: React.FC = () => {
  return (
    <footer
      className="bg-[#2d2d2d] mt-12 py-6"
      style={{
        backgroundImage: `url("data:image/svg+xml,%3csvg width='52' height='60' viewBox='0 0 52 60' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M26 0L0 15v30l26 15 26-15V15L26 0zm0 2.887L48.522 16.5v27L26 57.113 3.478 43.5v-27L26 2.887zM26 6.928L7.95 17.5v15l18.05 10.5 18.05-10.5v-15L26 6.928z' fill-rule='evenodd' fill-opacity='0.05' fill='%23FFF'/%3e%3c/svg%3e")`,
      }}
    >
      <div className="container mx-auto px-4 flex flex-col sm:flex-row justify-between items-center text-center sm:text-left">
        <p className="text-gray-400 text-sm mb-4 sm:mb-0">©Copyright 2025 POLIPASES</p>
        <div className="flex items-center space-x-4">
          <span className="text-gray-400 text-sm">Seguinos</span>
          <a href="#" className="text-gray-400 hover:text-white"><AtSymbolIcon /></a>
          <a href="#" className="text-gray-400 hover:text-white"><InstagramIcon /></a>
          <a href="#" className="text-gray-400 hover:text-white"><XIcon /></a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;