package com.prueba_basedatos.prueba_basedatos.repository;

import com.prueba_basedatos.prueba_basedatos.model.Rumor;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface RumorRepository extends JpaRepository<Rumor, Long> {

    @Transactional
    @Modifying
    @Query("UPDATE Rumor r SET r.valoracion = r.valoracion + 1 WHERE r.id_rumor = :id")
    void darLike(Long id);

    @Query("SELECT r FROM Rumor r WHERE r.usuario_rumor.id_usuario = :id")
    List<Rumor> findByUsuarioId(@Param("id") Long id);
}

