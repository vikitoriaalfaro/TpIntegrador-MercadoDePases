package com.prueba_basedatos.prueba_basedatos.controller;

import com.prueba_basedatos.prueba_basedatos.model.Equipo;
import com.prueba_basedatos.prueba_basedatos.repository.EquipoRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/equipos")
public class EquipoController {

    private final EquipoRepository equipoRepository;

    public EquipoController(EquipoRepository equipoRepository) {
        this.equipoRepository = equipoRepository;
    }

    @GetMapping
    public ResponseEntity<List<Equipo>> getEquipos() {
        List<Equipo> equipos = equipoRepository.findAll();
        equipos.forEach(e -> e.setEscudo(null)); // 👈 evitamos mandar bytes enormes
        return ResponseEntity.ok(equipos);
    }

    @GetMapping("/{id}/imagen")
    public ResponseEntity<byte[]> getEscudo(@PathVariable Long id) {
        Equipo equipo = equipoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Equipo no encontrado"));

        byte[] imagen = equipo.getEscudo();
        return ResponseEntity
                .ok()
                .header("Content-Type", "image/png")
                .body(imagen);
    }
}

