package com.prueba_basedatos.prueba_basedatos.dto;

import java.sql.Date;

import com.prueba_basedatos.prueba_basedatos.model.Equipo;

public class JugadorConEquipoDto {


    private String nombre_jugador;
    private String apellido;
    private String nacionalidad;
    private double altura;
    private  int peso;
    private int valor_mercado;
    private Date f_nacimiento;
    private String posicion;
    private int sueldo;
    private String equipo_nombre;
    private String jugador_imagen_url;

    public JugadorConEquipoDto(String nombre_jugador, String apellido, String nacionalidad, double altura, int peso, int valor_mercado, Date f_nacimiento, String posicion, int sueldo, String equipo_nombre, String jugador_imagen_url ) {

        this.nombre_jugador = nombre_jugador;
        this.apellido = apellido;
        this.nacionalidad = nacionalidad;
        this.altura = altura;
        this.peso = peso;
        this.valor_mercado = valor_mercado;
        this.f_nacimiento = f_nacimiento;
        this.posicion = posicion;
        this.sueldo = sueldo;
        this.equipo_nombre = equipo_nombre;
        this.jugador_imagen_url = jugador_imagen_url;
    }
    public JugadorConEquipoDto() {
    }

    public int getValor_mercado() {
        return valor_mercado;
    }

    public void setValor_mercado(int valor_mercado) {
        this.valor_mercado = valor_mercado;
    }

    public String getJugador_imagen_url() {
        return jugador_imagen_url;
    }

    public void setJugador_imagen(String jugador_imagen_url) {
        this.jugador_imagen_url = jugador_imagen_url;
    }

    public String getNombre_jugador() {
        return nombre_jugador;
    }

    public void setNombre_jugador(String nombre_jugador) {
        this.nombre_jugador = nombre_jugador;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }


    public Date getF_nacimiento() {
        return f_nacimiento;
    }

    public void setF_nacimiento(Date f_nacimiento) {
        this.f_nacimiento = f_nacimiento;
    }

    public String getPosicion() {
        return posicion;
    }

    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    public int getSueldo() {
        return sueldo;
    }

    public void setSueldo(int sueldo) {
        this.sueldo = sueldo;
    }

    public String getEquipo_nombre() {
        return equipo_nombre;
    }
    public void setEquipo_nombre(String equipo_nombre) {
        this.equipo_nombre = equipo_nombre;
    }
}
