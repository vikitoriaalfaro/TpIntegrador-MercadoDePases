package com.prueba_basedatos.prueba_basedatos.repository;

import com.prueba_basedatos.prueba_basedatos.model.Equipo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface EquipoRepository  extends JpaRepository<Equipo, Long> {
    @Query("SELECT e FROM Equipo e LEFT JOIN FETCH e.jugadores WHERE e.id_equipo = :id")
    Optional<Equipo> findByIdWithJugadores(@Param("id") Long id);
}
