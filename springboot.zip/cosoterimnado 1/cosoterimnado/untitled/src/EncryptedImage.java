import java.io.Serializable;

public class EncryptedImage implements Serializable {
    public byte[] iv;
    public byte[] data;
    public byte[] signature;

    public EncryptedImage(byte[] iv, byte[] data, byte[] signature) {
        this.iv = iv;
        this.data = data;
        this.signature = signature;
    }
}
