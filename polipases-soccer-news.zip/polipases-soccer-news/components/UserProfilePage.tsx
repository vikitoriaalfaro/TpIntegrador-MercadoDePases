import React, { useState, useEffect } from 'react';
import UserProfileHeader from './UserProfileHeader';
import UserProfileCard from './UserProfileCard';
import UserRumors from './UserRumors';
import UserIdealXI from './UserIdealXI';
import type { ApiUser, ApiRumor, ApiIdealXI } from '../types';

// The base URL of your Spring Boot backend
const API_BASE_URL = 'http://localhost:8080';
// Hardcoded user ID for fetching data. In a real app, this would be dynamic.
const USER_ID = 1;

// --- Mock Data for Static Components ---
const mockRumors: ApiRumor[] = [
  {
    id_rumor: 1,
    fecha: '2024-06-19',
    nombre_jugador: 'Ponck',
    equipo_viejo: 'Sin Equipo',
    equipo_nuevo: 'AVS FS',
    likes: 16,
    estado: 'Confirmado',
  },
  {
    id_rumor: 2,
    fecha: '2023-10-22',
    nombre_jugador: 'Jahanbakhsh, Alireza',
    equipo_viejo: 'Feyenoord',
    equipo_nuevo: 'FCV Dender EH',
    likes: 10,
    estado: 'Confirmado',
  },
  {
    id_rumor: 3,
    fecha: '2023-10-22',
    nombre_jugador: 'Burlet, Vincent',
    equipo_viejo: 'Lille',
    equipo_nuevo: 'US Boulogne',
    likes: 5,
    estado: 'En progreso',
  },
];

const mockIdealXI: ApiIdealXI = {
  portero: { nombre: 'Casteels, K.' },
  defensas: [
    { nombre: 'Dest, Sergiño' },
    { nombre: 'Costa, Ayrton' },
    { nombre: 'Di Lollo, L.' },
    { nombre: 'Baldé, A.' },
  ],
  mediocampistas: [
    { nombre: 'Soraluce, I.' },
    { nombre: 'Mac Allister, A.' },
    { nombre: 'Milla, Bernardo' },
  ],
  delanteros: [
    { nombre: 'Son, Heung-Min' },
    { nombre: 'Ndiaye, Iliman' },
    { nombre: 'Barco, Valentín' },
  ],
};
// --- End Mock Data ---


interface UserProfilePageProps {
  navigateToHome: () => void;
}

const UserProfilePage: React.FC<UserProfilePageProps> = ({ navigateToHome }) => {
  const [user, setUser] = useState<ApiUser | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        setLoading(true);
        // CORRECTED: Added the /api prefix to match the Spring Boot application's context path.
        const userResponse = await fetch(`${API_BASE_URL}/api/usuarios/${USER_ID}`);

        if (!userResponse.ok) {
          if (userResponse.status === 404) {
            throw new Error('No se encontró el usuario. Verifique que la URL y el ID sean correctos.');
          }
          throw new Error('No se pudo obtener la información del usuario.');
        }
        
        const userData: ApiUser = await userResponse.json();
        setUser(userData);

      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, []);

  const renderContent = () => {
    if (loading) {
      return (
        <div className="flex justify-center items-center h-96">
          <p className="text-gray-400 text-lg">Cargando perfil del usuario...</p>
        </div>
      );
    }

    if (error) {
      return (
        <div className="flex justify-center items-center h-96 bg-[#1a1a1a] rounded-2xl p-4 text-center">
          <p className="text-red-500 text-lg">Error: {error}</p>
        </div>
      );
    }

    if (!user) {
      return (
        <div className="flex justify-center items-center h-96 bg-[#1a1a1a] rounded-2xl">
          <p className="text-gray-400 text-lg">No se encontraron datos para este perfil.</p>
        </div>
      );
    }
    
    return (
      <>
        <UserProfileCard user={user} />
        <UserRumors rumors={mockRumors} />
        <UserIdealXI players={mockIdealXI} />
      </>
    );
  };


  return (
    <>
      <UserProfileHeader navigateToHome={navigateToHome} />
      <main className="mt-8 space-y-12">
        {renderContent()}
      </main>
    </>
  );
};

export default UserProfilePage;