package com.prueba_basedatos.prueba_basedatos.controller;

import com.prueba_basedatos.prueba_basedatos.dto.EquipoConJugadoresDTO;
import com.prueba_basedatos.prueba_basedatos.dto.EquipoDto;
import com.prueba_basedatos.prueba_basedatos.dto.JugadorNombreDTO;
import com.prueba_basedatos.prueba_basedatos.model.Equipo;
import com.prueba_basedatos.prueba_basedatos.model.Jugador;
import com.prueba_basedatos.prueba_basedatos.repository.EquipoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/equipos")
public class EquipoController {

    private final EquipoRepository equipoRepository;

    @Autowired // Optional in recent Spring, but explicit is fine
    public EquipoController(EquipoRepository equipoRepository) {
        this.equipoRepository = equipoRepository;
    }

    @GetMapping
    public ResponseEntity<List<EquipoDto>> getEquipos() {
        List<Equipo> equipos = equipoRepository.findAll();

        equipos.forEach(e -> {
            if (e.getLiga() != null) {
                e.getLiga().getNombre_liga(); // force initialization if LAZY
            }
        });

        List<EquipoDto> equiposDto = equipos.stream()
                .map(e -> new EquipoDto(
                        e.getId_equipo(),
                        e.getNombre_equipo(),
                        e.getEscudo() != null ? Base64.getEncoder().encodeToString(e.getEscudo()) : null,
                        e.getLiga() != null ? e.getLiga().getId_liga() : 0,
                        e.getLiga() != null ? e.getLiga().getNombre_liga() : "Sin liga",
                        e.getEstadio()
                ))
                .toList();

        return ResponseEntity.ok(equiposDto);
    }

    @GetMapping("/{id}/jugadores")
    public ResponseEntity<List<Jugador>> getJugadores(
            @PathVariable Long id,
            @RequestParam(required = false) Integer edad,
            @RequestParam(required = false) String posicion,
            @RequestParam(required = false) String nacionalidad) {

        // 1️⃣ Buscar el equipo
        Equipo equipo = equipoRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Equipo no encontrado"));

        // 2️⃣ Obtener la lista de jugadores
        List<Jugador> jugadores = equipo.getJugadores();
        if (jugadores == null || jugadores.isEmpty()) {
            return ResponseEntity.ok(Collections.emptyList());
        }

        // 3️⃣ Aplicar filtro (solo uno a la vez)
        List<Jugador> filtrados = new ArrayList<>(jugadores);

        if (edad != null) {
            filtrados = filtrados.stream()
                    .filter(j -> {
                        if (j.getF_nacimiento() == null) return false;
                        LocalDate nacimiento = j.getF_nacimiento().toLocalDate();
                        int edadJugador = Period.between(nacimiento, LocalDate.now()).getYears();
                        return edadJugador == edad;
                    })
                    .toList();

        } else if (posicion != null && !posicion.isEmpty()) {
            filtrados = filtrados.stream()
                    .filter(j -> posicion.equalsIgnoreCase(j.getPosicion()))
                    .toList();

        } else if (nacionalidad != null && !nacionalidad.isEmpty()) {
            filtrados = filtrados.stream()
                    .filter(j -> nacionalidad.equalsIgnoreCase(j.getNacionalidad()))
                    .toList();
        }

        // 4️⃣ Devolver resultado
        return ResponseEntity.ok(filtrados);
    }
    @GetMapping("/{id}")
    public ResponseEntity<EquipoConJugadoresDTO> getEquipo(@PathVariable Long id) {
        Equipo equipo = equipoRepository.findByIdWithJugadores(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Equipo no encontrado"));

        List<JugadorNombreDTO> jugadores = equipo.getJugadores().stream()
                .map(j -> new JugadorNombreDTO(j.getNombre_jugador(), j.getApellido()))
                .collect(Collectors.toList());

        EquipoConJugadoresDTO dto = new EquipoConJugadoresDTO(
                equipo.getId_equipo(),
                equipo.getNombre_equipo(),
                jugadores,
                equipo.getEstadio()
        );

        return ResponseEntity.ok(dto);
    }
}