package com.prueba_basedatos.prueba_basedatos.controller;

import com.prueba_basedatos.prueba_basedatos.dto.LigaDto;
import com.prueba_basedatos.prueba_basedatos.model.Equipo;
import com.prueba_basedatos.prueba_basedatos.model.Liga;
import com.prueba_basedatos.prueba_basedatos.repository.LigaRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/ligas")
public class LigaController {

    private final LigaRepository ligaRepository;

    public LigaController(LigaRepository ligaRepository) {
        this.ligaRepository = ligaRepository;
    }

    @PostMapping("/add")
    public ResponseEntity<String> addLiga(@RequestBody Liga liga) {
        ligaRepository.save(liga);
        return ResponseEntity.ok("Liga guardada con éxito");
    }

    @GetMapping
    public ResponseEntity<List<LigaDto>> getAllLigas() {
        List<Liga> ligas = ligaRepository.findAll();

        List<LigaDto> ligasDto = ligas.stream().map(l -> new LigaDto(
                l.getNombre_liga(),
                l.getPais_liga(),
                l.getDivision(),
                l.getInicio_mercado(),
                l.getFin_mercado(),
                "/ligas/" + l.getId_liga() + "/imagen"
        )).toList();

        return ResponseEntity.ok(ligasDto);
    }

    @GetMapping("/{id}/imagen")
    public ResponseEntity<byte[]> getImagen_liga(@PathVariable Long id) {
        Liga liga = ligaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Liga no encontrada"));

        byte[] imagen = liga.getImagen_liga();
        return ResponseEntity
                .ok()
                .header("Content-Type", "image/png")
                .body(imagen);
    }
}
