import React, { useState, useEffect } from 'react';
import type { ApiLeague } from '../types';
import { ChevronDownIcon } from './Icons';

// The base URL of your Spring Boot backend
const API_BASE_URL = 'http://localhost:8080';

const LeagueItem: React.FC<{ league: ApiLeague }> = ({ league }) => (
  <li className="flex items-center space-x-4 p-3 hover:bg-gray-700/50 rounded-lg cursor-pointer">
    <img
      src={`${API_BASE_URL}${league.imagen_liga_url}`}
      alt={league.nombre_liga}
      className="w-6 h-6 object-contain"
    />
    <span>{league.nombre_liga}</span>
  </li>
);

const Leagues: React.FC = () => {
  const [leagues, setLeagues] = useState<ApiLeague[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchLeagues = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/ligas`);
        if (!response.ok) {
          throw new Error('No se pudieron obtener los datos de las ligas');
        }
        const data: ApiLeague[] = await response.json();
        setLeagues(data);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchLeagues();
  }, []); // The empty dependency array ensures this effect runs only once

  const renderContent = () => {
    if (loading) {
      return <p className="text-center text-gray-400">Cargando ligas...</p>;
    }
    if (error) {
      return <p className="text-center text-red-500">Error: {error}</p>;
    }
    if (leagues.length === 0) {
      return <p className="text-center text-gray-400">No hay ligas para mostrar.</p>;
    }
    return (
      <ul>
        {leagues.map((league) => (
          <LeagueItem key={league.nombre_liga} league={league} />
        ))}
      </ul>
    );
  };

  return (
    <div className="bg-[#2d2d2d] rounded-2xl p-6 h-full">
      <h2 className="text-xl font-bold mb-4">Mejores ligas</h2>
      <button className="w-full bg-gray-700/50 text-white py-3 px-4 rounded-lg flex justify-between items-center mb-4">
        <span className="flex items-center space-x-2">
          <ChevronDownIcon />
          <span>Todas las ligas</span>
        </span>
      </button>
      {renderContent()}
    </div>
  );
};

export default Leagues;