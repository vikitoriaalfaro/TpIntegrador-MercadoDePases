import React, { useState, useEffect } from 'react';
import type { ApiNoticias } from '../types';

const API_BASE_URL = 'http://localhost:8080';

const Hero: React.FC = () => {
  const [newsItem, setNewsItem] = useState<ApiNoticias | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchNews = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/api/noticias`);
        if (!response.ok) {
          throw new Error('No se pudieron obtener las noticias');
        }
        const data: ApiNoticias[] = await response.json();

        if (data && data.length > 0) {
          // Select a random news item from the list
          const randomIndex = Math.floor(Math.random() * data.length);
          setNewsItem(data[randomIndex]);
        } else {
          setError('No hay noticias disponibles para mostrar.');
        }
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchNews();
  }, []); // Empty dependency array ensures this runs once on component mount

  if (loading) {
    return (
      <div className="relative rounded-2xl overflow-hidden bg-[#2d2d2d] h-64 md:h-96 flex items-center justify-center">
        <p className="text-gray-400">Cargando noticia principal...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="relative rounded-2xl overflow-hidden bg-[#2d2d2d] h-64 md:h-96 flex items-center justify-center p-6 text-center">
        <p className="text-red-500">Error: {error}</p>
      </div>
    );
  }

  if (!newsItem) {
    return null; // Or a fallback component if you prefer
  }
  
  // Your DTO creates a URL like "/noticias/1/imagen"
  // Your controller serves images from "/api/noticias/{id}/imagen"
  // We add the missing '/api' prefix here.
  const imageUrl = `${API_BASE_URL}/api${newsItem.imagen_noticia_url}`;

  return (
    <div className="relative rounded-2xl overflow-hidden bg-[#2d2d2d]">
      <img
        src={imageUrl}
        alt={newsItem.titulo}
        className="w-full h-64 md:h-96 object-cover"
        // In case the image fails to load
        onError={(e) => (e.currentTarget.style.display = 'none')}
      />
      <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black to-transparent p-6">
        <h1 className="text-xl md:text-2xl font-bold">
          Noticias: <span className="underline">{newsItem.titulo}</span>
        </h1>
      </div>
    </div>
  );
};

export default Hero;
