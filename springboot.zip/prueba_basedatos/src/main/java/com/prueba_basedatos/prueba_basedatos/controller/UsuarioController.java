package com.prueba_basedatos.prueba_basedatos.controller;

import com.prueba_basedatos.prueba_basedatos.dto.JugadorConEquipoDto;
import com.prueba_basedatos.prueba_basedatos.dto.JugadorDto;
import com.prueba_basedatos.prueba_basedatos.dto.UsuarioDto;
import com.prueba_basedatos.prueba_basedatos.model.Jugador;
import com.prueba_basedatos.prueba_basedatos.model.Liga;
import com.prueba_basedatos.prueba_basedatos.model.Usuario;
import com.prueba_basedatos.prueba_basedatos.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("api/usuarios")
@CrossOrigin(origins = "*")
public class UsuarioController {

    private final UserRepository userRepository;

    public UsuarioController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @PostMapping("/add")
    public ResponseEntity<String> addUsuario(@RequestBody Usuario usuario) {
        userRepository.save(usuario);
        return ResponseEntity.ok("Usuario guardado con éxito");
    }

    @GetMapping("/{id}/imagen")
    public ResponseEntity<byte[]> getImagenUsuario(@PathVariable Long id) {
        Usuario usuario = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        byte[] imagen = usuario.getFoto_usuario();
        return ResponseEntity
                .ok()
                .header("Content-Type", "image/png")
                .body(imagen);
    }

    @GetMapping("/{id}")
    public ResponseEntity<UsuarioDto> getUsuario(@PathVariable Long id) {
        return userRepository.findById(id)
                .map(usuario -> {
                    UsuarioDto dto = new UsuarioDto(
                            usuario.getNombre_usuario(),
                            usuario.getMail(),
                            usuario.getPuntos(),
                            usuario.getId_usuario(),
                            "/usuarios/" + usuario.getId_usuario() + "/imagen"
                    );
                    return ResponseEntity.ok(dto);
                })
                .orElse(ResponseEntity.notFound().build()); // Devuelve 404 si no lo encuentra
    }



    @PostMapping
    public ResponseEntity<Usuario> crearUsuario(@RequestBody Usuario usuario) {
        Usuario nuevo = userRepository.save(usuario);
        return ResponseEntity.ok(nuevo);
    }


}



