package com.prueba_basedatos.prueba_basedatos.dto;

import java.util.List;

public class EquipoConJugadoresDTO {
    private Long id_equipo;
    private String nombre_equipo;
    private List<JugadorNombreDTO> jugadores;
    private String estadio;

    public EquipoConJugadoresDTO(Long id_equipo, String nombre_equipo, List<JugadorNombreDTO> jugadores, String estadio) {
        this.id_equipo = id_equipo;
        this.nombre_equipo = nombre_equipo;
        this.jugadores = jugadores;
        this.estadio = estadio;
    }

    public Long getId_equipo() {
        return id_equipo;
    }

    public void setId_equipo(Long id_equipo) {
        this.id_equipo = id_equipo;
    }

    public String getNombre_equipo() {
        return nombre_equipo;
    }

    public void setNombre_equipo(String nombre_equipo) {
        this.nombre_equipo = nombre_equipo;
    }

    public List<JugadorNombreDTO> getJugadores() {
        return jugadores;
    }

    public void setJugadores(List<JugadorNombreDTO> jugadores) {
        this.jugadores = jugadores;
    }
    public String getEstadio() {
        return estadio;
    }
    public void setEstadio(String estadio) {
        this.estadio = estadio;
    }
}