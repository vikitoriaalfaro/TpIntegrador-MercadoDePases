package com.prueba_basedatos.prueba_basedatos.repository;

import com.prueba_basedatos.prueba_basedatos.model.Liga;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LigaRepository extends JpaRepository<Liga, Long> {
}
