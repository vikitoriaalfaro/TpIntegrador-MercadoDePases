package com.prueba_basedatos.prueba_basedatos.model;

import jakarta.persistence.*;
                                                                                  
import java.sql.Date;

@Entity
@Table(name = "jugador")
public class Jugador {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_jugador;

    private String nombre_jugador;
    private String apellido;
    private String nacionalidad;
    private double altura;
    private  int peso;
    private int valor_mercado;
    private Date f_nacimiento;
    private String posicion;
    private int sueldo;
    private byte[] imagen_jugador;

    @ManyToOne
    @JoinColumn(name = "equipo_idequipo")
    private Equipo equipo;

    public Jugador(Long id_jugador, String nombre_jugador, String apellido, String nacionalidad, double altura, int peso, int valor_mercado, Date f_nacimiento, String posicion, int sueldo, Equipo equipo, byte[] imagen_jugador) {
        this.id_jugador = id_jugador;
        this.nombre_jugador = nombre_jugador;
        this.apellido = apellido;                
        this.nacionalidad = nacionalidad;
        this.altura = altura;
        this.peso = peso;
        this.valor_mercado = valor_mercado;
        this.f_nacimiento = f_nacimiento;
        this.posicion = posicion;
        this.sueldo = sueldo;
        this.equipo = equipo;
        this.imagen_jugador = imagen_jugador;
    }
    public Jugador() {
    }

    public Long getId_jugador() {
        return id_jugador;
    }

    public int getValor_mercado() {
        return valor_mercado;
    }

    public void setValor_mercado(int valor_mercado) {
        this.valor_mercado = valor_mercado;
    }

    public byte[] getimagen_jugador() {
        return imagen_jugador;
    }

    public void setimagen_jugador(byte[] imagen_jugador) {
        this.imagen_jugador = imagen_jugador;
    }

    public void setId_jugador(Long id_jugador) {
        this.id_jugador = id_jugador;
    }

    public String getNombre_jugador() {
        return nombre_jugador;
    }

    public void setNombre_jugador(String nombre_jugador) {
        this.nombre_jugador = nombre_jugador;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }



    public Date getF_nacimiento() {
        return f_nacimiento;
    }

    public void setF_nacimiento(Date f_nacimiento) {
        this.f_nacimiento = f_nacimiento;
    }

    public String getPosicion() {
        return posicion;
    }

    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    public int getSueldo() {
        return sueldo;
    }

    public void setSueldo(int sueldo) {
        this.sueldo = sueldo;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }
}
