package com.prueba_basedatos.prueba_basedatos.model;

import jakarta.persistence.*;

@Entity
@Table(name = "noticia")
public class Noticia {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_noticia;

    private String titulo;
    private byte[] imagen_noticia;
    private String descripcion_corta;
    private String noticia_cuerpo;

    public Noticia(Long id_noticia, String titulo, byte[] imagen_noticia, String descripcion_corta, String noticia_cuerpo) {
        this.id_noticia = id_noticia;
        this.titulo = titulo;
        this.imagen_noticia = imagen_noticia;
        this.descripcion_corta = descripcion_corta;
        this.noticia_cuerpo = noticia_cuerpo;
    }

    public Noticia() {

    }

    public Long getId_noticia() {
        return id_noticia;
    }

    public void setId_noticia(Long id_noticia) {
        this.id_noticia = id_noticia;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public byte[] getImagen_noticia() {
        return imagen_noticia;
    }

    public void setImagen_noticia(byte[] imagen_noticia) {
        this.imagen_noticia = imagen_noticia;
    }

    public String getDescripcion_corta() {
        return descripcion_corta;
    }

    public void setDescripcion_corta(String descripcion_corta) {
        this.descripcion_corta = descripcion_corta;
    }

    public String getNoticia_cuerpo() {
        return noticia_cuerpo;
    }

    public void setNoticia_cuerpo(String noticia_cuerpo) {
        this.noticia_cuerpo = noticia_cuerpo;
    }
}
