package com.prueba_basedatos.prueba_basedatos.model;

import jakarta.persistence.*;

import java.sql.Date;

@Entity
@Table(name = "rumor")
public class Rumor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_rumor;

    @ManyToOne
    @JoinColumn(name = "jugador_idjugador_rumor")
    private Jugador jugador;

    @ManyToOne
    @JoinColumn(name = "equipo_idequipo_viejo_rumor")
    private Equipo equipo_viejo_rumor;

    @ManyToOne
    @JoinColumn(name = "equipo_idequipo_nuevo_rumor")
    private Equipo equipo_nuevo_rumor;

    @ManyToOne
    @JoinColumn(name = "usuario_id_usuario")
    private Usuario usuario_rumor;


    private String es_correcto;
    private int valoracion;
    private Date fecha_creacion;

    public Rumor(Long id_rumor, Jugador jugador, Equipo equipo_viejo_rumor, Equipo equipo_nuevo_rumor, Usuario usuario_rumor, String es_correcto, int valoracion, Date fecha_creacion) {
        this.id_rumor = id_rumor;
        this.jugador = jugador;
        this.equipo_viejo_rumor = equipo_viejo_rumor;
        this.equipo_nuevo_rumor = equipo_nuevo_rumor;
        this.usuario_rumor = usuario_rumor;
        this.es_correcto = es_correcto;
        this.valoracion = valoracion;
        this.fecha_creacion = fecha_creacion;
    }

    public Rumor() {}

    public Long getId_rumor() {
        return id_rumor;
    }

    public void setId_rumor(Long id_rumor) {
        this.id_rumor = id_rumor;
    }

    public Jugador getJugador() {
        return jugador;
    }

    public void setJugador(Jugador jugador) {
        this.jugador = jugador;
    }

    public Equipo getEquipo_viejo_rumor() {
        return equipo_viejo_rumor;
    }

    public void setEquipo_viejo_rumor(Equipo equipo_viejo_rumor) {
        this.equipo_viejo_rumor = equipo_viejo_rumor;
    }

    public Equipo getequipo_nuevo_rumor() {
        return equipo_nuevo_rumor;
    }

    public void setequipo_nuevo_rumor(Equipo equipo_nuevo_rumor) {
        this.equipo_nuevo_rumor = equipo_nuevo_rumor;
    }

    public Usuario getUsuario_rumor() {
        return usuario_rumor;
    }

    public void setUsuario_rumor(Usuario usuario_rumor) {
        this.usuario_rumor = usuario_rumor;
    }

    public String getEs_correcto() {
        return es_correcto;
    }

    public void setEs_correcto(String es_correcto) {
        this.es_correcto = es_correcto;
    }

    public int getValoracion() {
        return valoracion;
    }

    public void setValoracion(int valoracion) {
        this.valoracion = valoracion;
    }

    public Date getFecha_creacion() {
        return fecha_creacion;
    }

    public void setFecha_creacion(Date fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }
}
