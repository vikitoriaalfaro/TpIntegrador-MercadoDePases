import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Leagues from './components/Leagues';
import Transfers from './components/Transfers';
import CreateXI from './components/CreateXI';
import Rumors from './components/Rumors';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="bg-[#121212] text-white min-h-screen font-sans">
      <div className="container mx-auto px-4">
        <Header />
        <main className="py-6">
          <Hero />
          <div className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1">
              <Leagues />
            </div>
            <div className="lg:col-span-2">
              <Transfers />
            </div>
          </div>
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-8">
            <CreateXI />
            <Rumors />
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
};

export default App;