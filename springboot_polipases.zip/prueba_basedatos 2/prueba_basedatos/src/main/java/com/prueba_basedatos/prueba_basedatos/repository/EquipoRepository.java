package com.prueba_basedatos.prueba_basedatos.repository;

import com.prueba_basedatos.prueba_basedatos.model.Equipo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EquipoRepository  extends JpaRepository<Equipo, Long> {
}
