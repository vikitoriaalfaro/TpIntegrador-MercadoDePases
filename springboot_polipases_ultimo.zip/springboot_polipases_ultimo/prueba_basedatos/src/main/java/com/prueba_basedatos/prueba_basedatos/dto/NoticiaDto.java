package com.prueba_basedatos.prueba_basedatos.dto;

public class NoticiaDto {
    private String titulo;
    private String imagen_noticia_url;
    private String descripcion_corta;
    private String noticia_cuerpo;

    public NoticiaDto( String titulo, String imagen_noticia_url, String descripcion_corta, String noticia_cuerpo) {
        this.titulo = titulo;
        this.imagen_noticia_url = imagen_noticia_url;
        this.descripcion_corta = descripcion_corta;
        this.noticia_cuerpo = noticia_cuerpo;
    }


    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getImagen_noticia_url() {
        return imagen_noticia_url;
    }

    public void setImagen_noticia_url(String imagen_noticia_url) {
        this.imagen_noticia_url = imagen_noticia_url;
    }

    public String getDescripcion_corta() {
        return descripcion_corta;
    }

    public void setDescripcion_corta(String descripcion_corta) {
        this.descripcion_corta = descripcion_corta;
    }

    public String getNoticia_cuerpo() {
        return noticia_cuerpo;
    }

    public void setNoticia_cuerpo(String noticia_cuerpo) {
        this.noticia_cuerpo = noticia_cuerpo;
    }
}
