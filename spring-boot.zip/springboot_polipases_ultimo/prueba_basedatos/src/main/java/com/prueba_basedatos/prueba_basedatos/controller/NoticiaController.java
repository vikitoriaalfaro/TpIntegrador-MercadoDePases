package com.prueba_basedatos.prueba_basedatos.controller;

import com.prueba_basedatos.prueba_basedatos.dto.JugadorDto;
import com.prueba_basedatos.prueba_basedatos.dto.NoticiaDto;
import com.prueba_basedatos.prueba_basedatos.model.Jugador;
import com.prueba_basedatos.prueba_basedatos.model.Noticia;
import com.prueba_basedatos.prueba_basedatos.repository.JugadorRepository;
import com.prueba_basedatos.prueba_basedatos.repository.NoticiaRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/noticias")
public class NoticiaController {

    private final NoticiaRepository noticiaRepository;

    public NoticiaController(NoticiaRepository noticiaRepository) {
        this.noticiaRepository = noticiaRepository;
    }

    @GetMapping("/{id}/imagen")
    public ResponseEntity<byte[]> getImagenNoticia(@PathVariable Long id) {
        Noticia noticia = noticiaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Noticia no encontrada"));

        byte[] imagen = noticia.getImagen_noticia();
        return ResponseEntity
                .ok()
                .header("Content-Type", "image/png")
                .body(imagen);
    }

    @GetMapping
    public ResponseEntity<List<NoticiaDto>> getAllNoticias() {
        List<NoticiaDto> noticias = noticiaRepository.findAll()
                .stream()
                .map(j -> new NoticiaDto(
                        j.getTitulo(),
                        "/noticias/" + j.getId_noticia() + "/imagen",
                        j.getDescripcion_corta(),
                        j.getNoticia_cuerpo()
                ))
                .toList();

        return ResponseEntity.ok(noticias);
    }
}