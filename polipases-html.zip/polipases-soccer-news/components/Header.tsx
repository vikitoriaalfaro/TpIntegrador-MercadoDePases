
import React from 'react';
import { SearchIcon, SoccerBallIcon } from './Icons';

const Header: React.FC = () => {
  return (
    <header className="flex items-center justify-between py-4 border-b border-gray-700">
      <div className="flex items-center">
        {/* The SVG logo component has been replaced with this standard image tag */}
        <img src="/polipases-logo.png" alt="PoliPases Logo" className="h-20" />
        <a> polipases</a>
      </div>
      <div className="hidden md:flex flex-1 max-w-md mx-4">
        <div className="relative w-full">
          <span className="absolute inset-y-0 left-0 flex items-center pl-3">
            <SearchIcon />
          </span>
          <input
            type="text"
            placeholder="Busca por equipo, jugador o liga..."
            className="w-full bg-[#2d2d2d] text-white placeholder-gray-400 rounded-lg py-2 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-green-500"
          />
        </div>
      </div>
      <nav className="flex items-center space-x-6">
        <a href="#" className="hidden sm:block text-gray-300 hover:text-white">Fichajes</a>
        <a href="#" className="hidden sm:block text-gray-300 hover:text-white">Rumores</a>
        <a href="#" className="hidden sm:block text-gray-300 hover:text-white">XI ideal</a>
        <SoccerBallIcon />
      </nav>
    </header>
  );
};

export default Header;