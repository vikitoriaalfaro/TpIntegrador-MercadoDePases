package com.prueba_basedatos.prueba_basedatos.controller;

import com.prueba_basedatos.prueba_basedatos.model.Liga;
import com.prueba_basedatos.prueba_basedatos.model.Usuario;
import com.prueba_basedatos.prueba_basedatos.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    private final UserRepository userRepository;

    public UsuarioController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @PostMapping("/add")
    public ResponseEntity<String> addUsuario(@RequestBody Usuario usuario) {
        userRepository.save(usuario);
        return ResponseEntity.ok("Usuario guardado con éxito");
    }

    @GetMapping
    public ResponseEntity<List<Usuario>> getAllUsers() {
        return ResponseEntity.ok(userRepository.findAll());
    }

    @PostMapping
    public ResponseEntity<Usuario> crearUsuario(@RequestBody Usuario usuario) {
        Usuario nuevo = userRepository.save(usuario);
        return ResponseEntity.ok(nuevo);
    }
}



