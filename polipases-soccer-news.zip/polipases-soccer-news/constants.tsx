import React from 'react';

// The 'leagues' array has been removed as this data will now be fetched from your Spring Boot API.

  