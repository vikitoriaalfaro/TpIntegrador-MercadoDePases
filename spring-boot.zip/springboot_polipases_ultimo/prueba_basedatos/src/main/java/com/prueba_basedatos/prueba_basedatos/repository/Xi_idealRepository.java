package com.prueba_basedatos.prueba_basedatos.repository;

import com.prueba_basedatos.prueba_basedatos.model.Xi_ideal;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Xi_idealRepository extends JpaRepository<Xi_ideal, Long> {
}
