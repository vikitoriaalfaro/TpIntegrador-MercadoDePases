import java.io.Serializable;
import java.security.PublicKey;

public class ClavePublicaYRandomEncrypted implements Serializable {
    private final byte[] llaveRandomEncriptada;
    private final PublicKey llavePublica;
    private final byte[] signature;

    public ClavePublicaYRandomEncrypted(byte[] llaveRandomEncriptada, PublicKey llavePublica, byte[] signature) {
        this.llaveRandomEncriptada = llaveRandomEncriptada;
        this.llavePublica = llavePublica;
        this.signature = signature;
    }
    public byte[] getLlaveRandomEncriptada() { return llaveRandomEncriptada; }
    public PublicKey getLlavePublica() { return llavePublica; }
    public byte[] getSignature() { return signature; }
}
