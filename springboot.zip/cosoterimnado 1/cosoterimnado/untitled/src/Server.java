import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.net.*;
import java.security.*;
import java.util.*;
import java.util.concurrent.*;

public class Server {
    private static final int PORT = 5000;

    private static final List<ObjectOutputStream> clients =
            Collections.synchronizedList(new ArrayList<>());
    private static final ConcurrentHashMap<String, PublicKey> clientPublicKeys = new ConcurrentHashMap<>();

    private static KeyPair serverKeyPair;

    public static void main(String[] args) throws Exception {
        serverKeyPair = generateRSAKeyPair();
        System.out.println("Servidor: par de claves RSA generado.");

        ServerSocket serverSocket = new ServerSocket(PORT);
        System.out.println("Servidor escuchando en puerto " + PORT);

        ExecutorService pool = Executors.newCachedThreadPool();

        while (true) {
            Socket socket = serverSocket.accept();
            System.out.println("Cliente conectado: " + socket);
            pool.execute(new ClientHandler(socket));
        }
    }

    static class ClientHandler implements Runnable {
        private final Socket socket;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try (
                    ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                    ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
            ) {

                Object received = in.readObject();
                if (!(received instanceof PublicKey)) {
                    System.err.println("Servidor: no se recibió una clave pública válida desde " + socket);
                    return;
                }
                PublicKey clientPub = (PublicKey) received;
                String clientId = getClientId(clientPub);
                clientPublicKeys.put(clientId, clientPub);

                SecretKey clientLlaveRandom = getLlaveRandom();
                byte[] clientLlaveRandomEncrypted = getLlaveRandomEncrypted(clientPub, clientLlaveRandom);
                byte[] signature = CryptoUtils.sign(clientLlaveRandomEncrypted, serverKeyPair.getPrivate());
                EnviarClaves(clientLlaveRandomEncrypted, signature, out);

                synchronized (clients) {
                    clients.add(out);
                }

                while (true) {
                    Object obj = in.readObject();
                    if (obj instanceof EncryptedImage paquet) {

                        PublicKey pub = getPublicKey(clientId);

                        if (pub == null) continue;
                        if (firmaEsValida(paquet, pub, clientId)) continue;

                        byte[] decryptedImage = getDecryptedImage(paquet, clientLlaveRandom);
                        ServerSignedImage signedImage = getServerSignedImage(decryptedImage);

                        broadcastObject(signedImage);
                    } else {
                        System.out.println("Servidor: objeto inesperado " + obj.getClass());
                    }
                }

            } catch (EOFException eof) {
                System.out.println("Cliente desconectado (EOF): " + socket);
            } catch (Exception e) {
                System.out.println("Cliente desconectado: " + socket + " -> " + e.getMessage());
                e.printStackTrace();
            } finally {
                try { socket.close(); } catch (IOException ignored) {}
            }
        }

        private String getClientId(PublicKey clientPub) {
            String clientId = socket.getRemoteSocketAddress().toString();
            System.out.println("Servidor: recibida clave pública del cliente " + clientId);
            return clientId;
        }

        private ServerSignedImage getServerSignedImage(byte[] decryptedImage) throws Exception {
            byte[] serverSignature = CryptoUtils.sign(decryptedImage, serverKeyPair.getPrivate());
            ServerSignedImage signedImage = new ServerSignedImage(decryptedImage, serverSignature);
            return signedImage;
        }

        private static byte[] getDecryptedImage(EncryptedImage paquet, SecretKey clientLlaveRandom) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
            Cipher decipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            IvParameterSpec ivSpec = new IvParameterSpec(paquet.iv);
            decipher.init(Cipher.DECRYPT_MODE, clientLlaveRandom, ivSpec);
            byte[] decryptedImage = decipher.doFinal(paquet.data);
            return decryptedImage;
        }

        private static boolean firmaEsValida(EncryptedImage paquet, PublicKey pub, String clientId) throws Exception {
            byte[] dataToVerify = CryptoUtils.concat(paquet.iv, paquet.data);
            boolean ok = CryptoUtils.verify(dataToVerify, paquet.signature, pub);
            if (!ok) {
                System.out.println("Servidor: firma inválida del cliente " + clientId + ", descartando paquete.");
                return true;
            }
            return false;
        }

        private PublicKey getPublicKey(String clientId) {
            PublicKey pub = clientPublicKeys.get(clientId);
            if (pub == null) {
                System.out.println("Servidor: no tengo la clave pública de " + clientId + ", descarto.");
                return null;
            }
            return pub;
        }

        private void EnviarClaves(byte[] clientLlaveRandomEncrypted, byte[] signature, ObjectOutputStream out) throws IOException {
            ClavePublicaYRandomEncrypted paquete = new ClavePublicaYRandomEncrypted(clientLlaveRandomEncrypted, serverKeyPair.getPublic(), signature);
            out.writeObject(paquete);
            out.flush();
            System.out.println("Servidor: enviadas claves al cliente.");
        }

        private static byte[] getLlaveRandomEncrypted(PublicKey clientPub, SecretKey clientLlaveRandom) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
            Cipher rsaCipher = Cipher.getInstance("RSA");
            rsaCipher.init(Cipher.ENCRYPT_MODE, clientPub);
            byte[] clientLlaveRandomEncrypted = rsaCipher.doFinal(clientLlaveRandom.getEncoded());
            return clientLlaveRandomEncrypted;
        }

        private static SecretKey getLlaveRandom() throws NoSuchAlgorithmException {
            KeyGenerator keyGen = KeyGenerator.getInstance("AES");
            keyGen.init(256);
            SecretKey clientLlaveRandom = keyGen.generateKey();
            return clientLlaveRandom;
        }
    }

    private static void broadcastObject(Object o) {
        synchronized (clients) {
            Iterator<ObjectOutputStream> it = clients.iterator();
            while (it.hasNext()) {
                try {
                    ObjectOutputStream out = it.next();
                    out.writeObject(o);
                    out.flush();
                } catch (IOException e) {
                    it.remove();
                }
            }
        }
    }

    private static KeyPair generateRSAKeyPair() throws NoSuchAlgorithmException {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048);
        return keyGen.generateKeyPair();
    }
}