

import React, { useState } from 'react';
import HomePage from './components/HomePage';
import UserProfilePage from './components/UserProfilePage';
import Footer from './components/Footer';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState('home');

  const navigateToHome = () => setCurrentPage('home');
  const navigateToProfile = () => setCurrentPage('profile');

  return (
    <div className="bg-[#0D0D0D] text-white min-h-screen font-sans">
      <div className="container mx-auto px-4">
        {currentPage === 'home' ? (
          <HomePage navigateToProfile={navigateToProfile} />
        ) : (
          <UserProfilePage navigateToHome={navigateToHome} />
        )}
      </div>
      <Footer />
    </div>
  );
};
export default App;
