package com.prueba_basedatos.prueba_basedatos.model;

import jakarta.persistence.*;

@Entity
@Table(name = "Usuario")
public class Usuario {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long id_usuario;
    private String nombre_usuario;
    private String mail;
    private String contrasenia;
    private int puntos;

    public Usuario(long id_usuario, String nombre_usuario, String mail, String contrasenia, int puntos) {
        this.id_usuario = id_usuario;
        this.nombre_usuario = nombre_usuario;
        this.mail = mail;
        this.contrasenia = contrasenia;
        this.puntos = puntos;
    }

    public Usuario() {

    }

    public long getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(long id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getNombre_usuario() {
        return nombre_usuario;
    }

    public void setNombre_usuario(String nombre_usuario) {
        this.nombre_usuario = nombre_usuario;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }
}
