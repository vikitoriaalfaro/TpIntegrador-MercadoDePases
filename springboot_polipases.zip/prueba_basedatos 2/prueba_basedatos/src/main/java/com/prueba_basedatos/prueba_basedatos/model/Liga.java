package com.prueba_basedatos.prueba_basedatos.model;


import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "Liga")
public class Liga {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long id_liga;
    private String nombre_liga;
    private String pais_liga;
    private int division;
    private LocalDate inicio_mercado;
    private LocalDate fin_mercado;
    private byte[] imagen_liga;

    public Liga(long id_liga, String nombre_liga, String pais_liga, int division, LocalDate inicio_mercado, LocalDate fin_mercado, byte[] imagen_liga) {
        this.id_liga = id_liga;
        this.nombre_liga = nombre_liga;
        this.pais_liga = pais_liga;
        this.division = division;
        this.inicio_mercado = inicio_mercado;
        this.fin_mercado = fin_mercado;
        this.imagen_liga = imagen_liga;
    }
    public Liga() {}

    public long getId_liga() {
        return id_liga;
    }

    public byte[] getImagen_liga() {
        return imagen_liga;
    }

    public void setImagen_liga(byte[] imagen_liga) {
        this.imagen_liga = imagen_liga;
    }

    public void setId_liga(long id_liga) {
        this.id_liga = id_liga;
    }

    public String getNombre_liga() {
        return nombre_liga;
    }

    public void setNombre_liga(String nombre_liga) {
        this.nombre_liga = nombre_liga;
    }

    public String getPais_liga() {
        return pais_liga;
    }

    public void setPais_liga(String pais_liga) {
        this.pais_liga = pais_liga;
    }

    public int getDivision() {
        return division;
    }

    public void setDivision(int division) {
        this.division = division;
    }

    public LocalDate getInicio_mercado() {
        return inicio_mercado;
    }

    public void setInicio_mercado(LocalDate inicio_mercado) {
        this.inicio_mercado = inicio_mercado;
    }

    public LocalDate getFin_mercado() {
        return fin_mercado;
    }

    public void setFin_mercado(LocalDate fin_mercado) {
        this.fin_mercado = fin_mercado;
    }
}
