import React from 'react';
import type { ApiPlayer, ApiIdealXI } from '../types';

interface UserIdealXIProps {
  players: ApiIdealXI;
}

const PlayerMarker: React.FC<{ player: ApiPlayer }> = ({ player }) => {
  const imageUrl = `https://ui-avatars.com/api/?name=${player.nombre.replace(' ', '+')}&background=4a5568&color=fff&size=64`;

  return (
    <div className="flex flex-col items-center text-center w-20">
      <div className="w-14 h-14 rounded-lg bg-gray-700 border-2 border-gray-500 flex items-center justify-center text-2xl font-bold mb-1 overflow-hidden">
        <div className="w-full h-full bg-cover bg-center" style={{backgroundImage: `url(${imageUrl})`}}></div>
      </div>
      <span className="text-xs font-semibold bg-black/50 px-2 py-1 rounded">{player.nombre}</span>
    </div>
  );
};


const Pitch: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="relative w-full aspect-[7/5] bg-gray-500/20 rounded-xl overflow-hidden p-4 md:p-8">
    {/* Pitch markings */}
    <div className="absolute inset-4 md:inset-8 border-2 border-white/20">
      {/* Center line */}
      <div className="absolute top-0 left-1/2 w-0.5 h-full bg-white/20"></div>
      {/* Center circle */}
      <div className="absolute top-1/2 left-1/2 w-24 h-24 md:w-32 md:h-32 border-2 border-white/20 rounded-full transform -translate-x-1/2 -translate-y-1/2"></div>
      {/* Center spot */}
      <div className="absolute top-1/2 left-1/2 w-2 h-2 bg-white/50 rounded-full transform -translate-x-1/2 -translate-y-1/2"></div>
      {/* Goal areas */}
      <div className="absolute top-1/2 left-0 w-16 h-48 md:w-24 md:h-64 border-2 border-l-0 border-white/20 transform -translate-y-1/2"></div>
      <div className="absolute top-1/2 right-0 w-16 h-48 md:w-24 md:h-64 border-2 border-r-0 border-white/20 transform -translate-y-1/2"></div>
       {/* Small Goal areas */}
      <div className="absolute top-1/2 left-0 w-8 h-24 md:w-12 md:h-36 border-2 border-l-0 border-white/20 transform -translate-y-1/2"></div>
      <div className="absolute top-1/2 right-0 w-8 h-24 md:w-12 md:h-36 border-2 border-r-0 border-white/20 transform -translate-y-1/2"></div>
    </div>
     {/* Corner arcs */}
    <div className="absolute top-4 left-4 w-8 h-8 border-t-2 border-l-2 border-white/20 rounded-tl-full transform -translate-x-1/2 -translate-y-1/2"></div>
    <div className="absolute top-4 right-4 w-8 h-8 border-t-2 border-r-2 border-white/20 rounded-tr-full transform translate-x-1/2 -translate-y-1/2"></div>
    <div className="absolute bottom-4 left-4 w-8 h-8 border-b-2 border-l-2 border-white/20 rounded-bl-full transform -translate-x-1/2 translate-y-1/2"></div>
    <div className="absolute bottom-4 right-4 w-8 h-8 border-b-2 border-r-2 border-white/20 rounded-br-full transform translate-x-1/2 translate-y-1/2"></div>

    <div className="relative w-full h-full z-10">
      {children}
    </div>
  </div>
);


const UserIdealXI: React.FC<UserIdealXIProps> = ({ players }) => {
  return (
    <div className="bg-[#1a1a1a] rounded-2xl p-6 shadow-lg">
      <h2 className="text-xl font-bold mb-4">Mi XI ideal</h2>
      <div className="relative">
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 bg-gray-800/80 px-6 py-2 rounded-lg font-bold text-lg tracking-widest">
            POLIPASES
        </div>
         <Pitch>
            {/* Goalkeeper */}
            <div className="absolute top-[85%] left-1/2 -translate-x-1/2 -translate-y-1/2"><PlayerMarker player={players.portero} /></div>
            
            {/* Defenders */}
            <div className="absolute top-[68%] left-[15%] -translate-x-1/2 -translate-y-1/2"><PlayerMarker player={players.defensas[0]} /></div>
            <div className="absolute top-[68%] left-[37%] -translate-x-1/2 -translate-y-1/2"><PlayerMarker player={players.defensas[1]} /></div>
            <div className="absolute top-[68%] left-[63%] -translate-x-1/2 -translate-y-1/2"><PlayerMarker player={players.defensas[2]} /></div>
            <div className="absolute top-[68%] left-[85%] -translate-x-1/2 -translate-y-1/2"><PlayerMarker player={players.defensas[3]} /></div>
            
            {/* Midfielders */}
            <div className="absolute top-[48%] left-[25%] -translate-x-1/2 -translate-y-1/2"><PlayerMarker player={players.mediocampistas[0]} /></div>
            <div className="absolute top-[48%] left-1/2 -translate-x-1/2 -translate-y-1/2"><PlayerMarker player={players.mediocampistas[1]} /></div>
            <div className="absolute top-[48%] left-[75%] -translate-x-1/2 -translate-y-1/2"><PlayerMarker player={players.mediocampistas[2]} /></div>
            
            {/* Forwards */}
            <div className="absolute top-[25%] left-[25%] -translate-x-1/2 -translate-y-1/2"><PlayerMarker player={players.delanteros[0]} /></div>
            <div className="absolute top-[25%] left-1/2 -translate-x-1/2 -translate-y-1/2"><PlayerMarker player={players.delanteros[1]} /></div>
            <div className="absolute top-[25%] left-[75%] -translate-x-1/2 -translate-y-1/2"><PlayerMarker player={players.delanteros[2]} /></div>
         </Pitch>
      </div>
    </div>
  );
};

export default UserIdealXI;