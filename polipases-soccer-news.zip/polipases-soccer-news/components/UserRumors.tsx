import React, { useState } from 'react';
import { HeartIcon, GreenArrowLongIcon } from './Icons';
import type { ApiRumor } from '../types';

// Helper function to format an ISO date string to a more readable format.
const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleDateString('es-ES', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });
};

interface UserRumorsProps {
  rumors: ApiRumor[];
}

const PlayerPlaceholder: React.FC<{ name: string }> = ({ name }) => {
  const finalImageUrl = `https://ui-avatars.com/api/?name=${name.replace(' ', '+')}&background=4b5563&color=fff&size=64`;
  return (
    <div className="w-12 h-12 rounded-full bg-gray-600 flex items-center justify-center text-xl font-bold overflow-hidden">
      <div className="w-full h-full bg-cover bg-center" style={{backgroundImage: `url(${finalImageUrl})`}}></div>
    </div>
  );
};

const TeamLogoPlaceholder: React.FC = () => {
  return (
    <div className="w-12 h-12 bg-gray-700 flex items-center justify-center font-bold text-sm rounded-md overflow-hidden" />
  );
};

const RumorItem: React.FC<{ rumor: ApiRumor }> = ({ rumor }) => {
  const nameParts = rumor.nombre_jugador.split(',');
  const lastName = nameParts[0];
  const firstName = nameParts.length > 1 ? nameParts[1].trim() : '';

  return (
    <div className="bg-[#1a1a1a] rounded-2xl p-4 flex items-center justify-between shadow-lg">
      <div className="flex items-center space-x-4">
        <PlayerPlaceholder name={rumor.nombre_jugador} />
        <div>
          <p className="text-xs text-gray-400">{formatDate(rumor.fecha)}</p>
          <p className="text-sm text-gray-300">{rumor.equipo_viejo}</p>
          <p className="text-xs font-semibold text-green-400">{rumor.estado}</p>
        </div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center mx-4">
        <h3 className="font-bold text-lg">{lastName}</h3>
        {firstName && <h4 className="font-bold text-lg">{firstName}</h4>}
        <div className="mt-1">
          <GreenArrowLongIcon />
        </div>
      </div>

      <div className="flex items-center space-x-4">
        <div className="text-right">
          <p className="text-sm font-semibold">{rumor.equipo_nuevo}</p>
          <div className="flex items-center justify-end space-x-1 mt-1 text-gray-400">
            <span>{rumor.likes}</span>
            <HeartIcon className="w-4 h-4 text-gray-500" />
          </div>
        </div>
        <TeamLogoPlaceholder />
      </div>
    </div>
  );
};


const UserRumors: React.FC<UserRumorsProps> = ({ rumors }) => {
  const [activeTab, setActiveTab] = useState('correctos');

  // This is a simple filter. A real implementation might need more complex logic
  // based on the 'estado' field from the API.
  const filteredRumors = rumors.filter(rumor => 
    activeTab === 'correctos' ? rumor.estado === 'Confirmado' : true
  );

  return (
    <div>
      <div className="flex items-center space-x-6 border-b border-gray-800 mb-6">
        <button
          onClick={() => setActiveTab('correctos')}
          className={`py-2 text-lg font-semibold transition ${
            activeTab === 'correctos'
              ? 'text-white border-b-2 border-green-500'
              : 'text-gray-500 hover:text-gray-300'
          }`}
        >
          Mis rumores acertados
        </button>
        <button
          onClick={() => setActiveTab('todos')}
          className={`py-2 text-lg font-semibold transition ${
            activeTab === 'todos'
              ? 'text-white border-b-2 border-green-500'
              : 'text-gray-500 hover:text-gray-300'
          }`}
        >
          Todos mis rumores
        </button>
      </div>

      <div className="space-y-4">
        {filteredRumors.length > 0 ? (
          filteredRumors.map((rumor) => (
            <RumorItem key={rumor.id_rumor} rumor={rumor} />
          ))
        ) : (
          <div className="text-center py-8 text-gray-500">
            No hay rumores en esta categoría.
          </div>
        )}
      </div>
    </div>
  );
};

export default UserRumors;