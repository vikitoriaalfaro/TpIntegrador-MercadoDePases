package com.prueba_basedatos.prueba_basedatos.dto;

public class UsuarioDto {
    private String nombre_usuario;
    private String mail;
    private int puntos;

    public UsuarioDto() {}

    public UsuarioDto(String nombre_usuario, String mail, int puntos) {
        this.nombre_usuario = nombre_usuario;
        this.mail = mail;
        this.puntos = puntos;
    }

    public String getNombre_usuario() {
        return nombre_usuario;
    }

    public void setNombre_usuario(String nombre_usuario) {
        this.nombre_usuario = nombre_usuario;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }
}
