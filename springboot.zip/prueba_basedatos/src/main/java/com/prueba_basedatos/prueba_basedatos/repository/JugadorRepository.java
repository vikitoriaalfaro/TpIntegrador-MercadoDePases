package com.prueba_basedatos.prueba_basedatos.repository;

import com.prueba_basedatos.prueba_basedatos.model.Jugador;
import org.antlr.v4.runtime.atn.SemanticContext;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface JugadorRepository extends JpaRepository<Jugador, Long> {

    @Query("SELECT j FROM Jugador j " +
            "WHERE LOWER(j.nombre_jugador) LIKE LOWER(CONCAT('%', :texto, '%')) " +
            "OR LOWER(j.apellido) LIKE LOWER(CONCAT('%', :texto, '%'))")
    List<Jugador> buscarPorNombreOApellido(@Param("texto") String texto);





}
