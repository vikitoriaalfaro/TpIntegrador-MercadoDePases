package com.prueba_basedatos.prueba_basedatos.dto;

import java.sql.Date;
import java.sql.Timestamp;

public class RumorDto {
    private Long id_rumor;
    private String apellido_jugador_rumor;
    private String nombre_jugador_rumor;
    private String equipo_viejo_rumor;
    private String equipo_nuevo_rumor;
    private String usuario_rumor;
    private String es_correcto;
    private int valoracion;
    private Date fecha_creacion;
    private String jugador_imagen_url;
    private String equipo_nuevo_imagen_url;


    public RumorDto(Long id_rumor, String apellidoJugadorRumor, String nombre_jugador_rumor, String equipo_viejo_rumor, String equipo_nuevo_rumor, String usuario_rumor, String es_correcto, int valoracion, Date fecha_creacion, String jugadorImagenUrl, String equipoNuevoImagenUrl) {
        this.id_rumor = id_rumor;
        apellido_jugador_rumor = apellidoJugadorRumor;
        this.nombre_jugador_rumor = nombre_jugador_rumor;
        this.equipo_viejo_rumor = equipo_viejo_rumor;
        this.equipo_nuevo_rumor = equipo_nuevo_rumor;
        this.usuario_rumor = usuario_rumor;
        this.es_correcto = es_correcto;
        this.valoracion = valoracion;
        this.fecha_creacion = fecha_creacion;
        this.jugador_imagen_url = jugadorImagenUrl;
        this.equipo_nuevo_imagen_url = equipoNuevoImagenUrl;
    }

    public RumorDto() {

    }

    public String getApellido_jugador_rumor() {
        return apellido_jugador_rumor;
    }

    public void setApellido_jugador_rumor(String apellido_jugador_rumor) {
        this.apellido_jugador_rumor = apellido_jugador_rumor;
    }

    public Long getId_rumor() {
        return id_rumor;
    }

    public String getJugador_imagen_url() {
        return jugador_imagen_url;
    }

    public void setJugador_imagen_url(String jugador_imagen_url) {
        this.jugador_imagen_url = jugador_imagen_url;
    }

    public String getEquipo_nuevo_imagen_url() {
        return equipo_nuevo_imagen_url;
    }

    public void setEquipo_nuevo_imagen_url(String equipo_nuevo_imagen_url) {
        this.equipo_nuevo_imagen_url = equipo_nuevo_imagen_url;
    }

    public void setId_rumor(Long id_rumor) {
        this.id_rumor = id_rumor;
    }

    public String getNombre_jugador_rumor() {
        return nombre_jugador_rumor;
    }

    public void setNombre_jugador_rumor(String nombre_jugador_rumor) {
        this.nombre_jugador_rumor = nombre_jugador_rumor;
    }

    public String getEquipo_viejo_rumor() {
        return equipo_viejo_rumor;
    }

    public void setEquipo_viejo_rumor(String equipo_viejo_rumor) {
        this.equipo_viejo_rumor = equipo_viejo_rumor;
    }

    public String getEquipo_nuevo_rumor() {
        return equipo_nuevo_rumor;
    }

    public void setEquipo_nuevo_rumor(String equipo_nuevo_rumor) {
        this.equipo_nuevo_rumor = equipo_nuevo_rumor;
    }

    public String getUsuario_rumor() {
        return usuario_rumor;
    }

    public void setUsuario_rumor(String usuario_rumor) {
        this.usuario_rumor = usuario_rumor;
    }

    public String getEs_correcto() {
        return es_correcto;
    }

    public void setEs_correcto(String es_correcto) {
        this.es_correcto = es_correcto;
    }

    public int getValoracion() {
        return valoracion;
    }

    public void setValoracion(int valoracion) {
        this.valoracion = valoracion;
    }

    public Date getFecha_creacion() {
        return fecha_creacion;
    }

    public void setFecha_creacion(Date fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }
}
