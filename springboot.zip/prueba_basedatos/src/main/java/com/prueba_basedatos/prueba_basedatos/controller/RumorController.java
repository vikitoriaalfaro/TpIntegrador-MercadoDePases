package com.prueba_basedatos.prueba_basedatos.controller;

import com.prueba_basedatos.prueba_basedatos.dto.RumorDto;
import com.prueba_basedatos.prueba_basedatos.model.*;
import com.prueba_basedatos.prueba_basedatos.repository.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/rumores")
@CrossOrigin(origins = "*")
public class RumorController {
    private final RumorRepository rumorRepository;
    private final JugadorRepository jugadorRepository;
    private final EquipoRepository equipoRepository;
    private final UserRepository userRepository;

    public RumorController(RumorRepository rumorRepository, JugadorRepository jugadorRepository, EquipoRepository equipoRepository, UserRepository userRepository) {
        this.rumorRepository = rumorRepository;
        this.jugadorRepository = jugadorRepository;
        this.equipoRepository = equipoRepository;
        this.userRepository = userRepository;
    }

    @PostMapping("/add")
    public ResponseEntity<String> addRumor(@RequestBody Map<String, Long> body) {
        Long idJugador = body.get("id_jugador");
        Long idEquipoViejo = body.get("id_equipo_viejo");
        Long idEquipoNuevo = body.get("id_equipo_nuevo");
        Long idUsuario = body.get("id_usuario");

        Jugador jugador = jugadorRepository.findById(idJugador)
                .orElseThrow(() -> new RuntimeException("Jugador no encontrado"));
        Equipo equipoViejo = equipoRepository.findById(idEquipoViejo)
                .orElseThrow(() -> new RuntimeException("Equipo viejo no encontrado"));
        Equipo equipoNuevo = equipoRepository.findById(idEquipoNuevo)
                .orElseThrow(() -> new RuntimeException("Equipo nuevo no encontrado"));
        Usuario usuario = userRepository.findById(idUsuario)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        Rumor nuevo = new Rumor();
        nuevo.setJugador(jugador);
        nuevo.setEquipo_viejo_rumor(equipoViejo);
        nuevo.setequipo_nuevo_rumor(equipoNuevo);
        nuevo.setUsuario_rumor(usuario);
        nuevo.setEs_correcto("POR_DEFINIR");
        nuevo.setValoracion(0);
        nuevo.setFecha_creacion(new java.sql.Date(System.currentTimeMillis()));

        rumorRepository.save(nuevo);
        return ResponseEntity.ok("Rumor registrado con éxito");
    }

    @PostMapping("/{id}/valorar")
    public ResponseEntity<String> valorarRumor(@PathVariable Long id) {
        rumorRepository.darLike(id);
        return ResponseEntity.ok("Rumor valorado con éxito");
    }

    @GetMapping("usuarios/{usuario_id}/rumores")
    public ResponseEntity<List<RumorDto>> getRumoresPorUsuario(@PathVariable Long usuario_id) {
        List<Rumor> rumores = rumorRepository.findByUsuarioId(usuario_id);
        List<RumorDto> rumoresDto = rumores.stream()
                .map(this::convertirARumorDto)
                .collect(Collectors.toList());

        return ResponseEntity.ok(rumoresDto);
    }

    private RumorDto convertirARumorDto(Rumor rumor) {
        RumorDto dto = new RumorDto();
        dto.setId_rumor(rumor.getId_rumor());
        dto.setApellido_jugador_rumor(rumor.getJugador().getApellido() + "," +   rumor.getJugador().getNombre_jugador());
        dto.setNombre_jugador_rumor(rumor.getJugador().getNombre_jugador());
        dto.setEquipo_viejo_rumor(rumor.getEquipo_viejo_rumor().getNombre_equipo());
        dto.setEquipo_nuevo_rumor(rumor.getequipo_nuevo_rumor().getNombre_equipo());
        dto.setUsuario_rumor(rumor.getUsuario_rumor().getNombre_usuario());
        dto.setEs_correcto(rumor.getEs_correcto());
        dto.setValoracion(rumor.getValoracion());
        dto.setFecha_creacion(rumor.getFecha_creacion());
        // Aquí es donde enlazamos las URLs de las imágenes
        dto.setJugador_imagen_url("/jugadores/" + rumor.getJugador().getId_jugador() + "/imagen");
        dto.setEquipo_nuevo_imagen_url("/equipos/" + rumor.getequipo_nuevo_rumor().getId_equipo() + "/imagen");
        return dto;
    }





}
