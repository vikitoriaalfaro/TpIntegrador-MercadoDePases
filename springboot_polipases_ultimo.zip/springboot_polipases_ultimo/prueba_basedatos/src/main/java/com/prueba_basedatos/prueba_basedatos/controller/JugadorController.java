package com.prueba_basedatos.prueba_basedatos.controller;

import com.prueba_basedatos.prueba_basedatos.dto.JugadorConEquipoDto;
import com.prueba_basedatos.prueba_basedatos.dto.JugadorDto;
import com.prueba_basedatos.prueba_basedatos.model.Equipo;
import com.prueba_basedatos.prueba_basedatos.model.Jugador;
import com.prueba_basedatos.prueba_basedatos.model.Liga;
import com.prueba_basedatos.prueba_basedatos.model.Usuario;
import com.prueba_basedatos.prueba_basedatos.repository.JugadorRepository;
import com.prueba_basedatos.prueba_basedatos.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Base64;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/jugadores")
public class JugadorController {

    private final JugadorRepository jugadorRepository;

    public JugadorController(JugadorRepository jugadorRepository) {
        this.jugadorRepository = jugadorRepository;
    }

    @PostMapping("/add")
    public ResponseEntity<String> addJugador(@RequestBody Jugador jugador) {
        jugadorRepository.save(jugador);
        return ResponseEntity.ok("Jugador guardado con éxito");
    }

    @GetMapping("/{id}/imagen")
    public ResponseEntity<byte[]> getImagenJugador(@PathVariable Long id) {
        Jugador jugador = jugadorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Jugador no encontrado"));

        byte[] imagen = jugador.getimagen_jugador();
        return ResponseEntity
                .ok()
                .header("Content-Type", "image/png")
                .body(imagen);
    }

    @GetMapping
    public ResponseEntity<List<JugadorDto>> getAllJugadores() {
        List<JugadorDto> jugadores = jugadorRepository.findAll()
                .stream()
                .map(j -> new JugadorDto(
                        j.getNombre_jugador(),
                        j.getApellido(),
                        j.getNacionalidad(),
                        j.getAltura(),
                        j.getPeso(),
                        j.getValor_mercado(),
                        j.getF_nacimiento(),
                        j.getPosicion(),
                        j.getSueldo(),
                        j.getEquipo(),
                        j.getEquipo() != null ? j.getEquipo().getNombre_equipo() : "Sin equipo",
                        "/jugadores/" + j.getId_jugador() + "/imagen"
                ))
                .toList();

        return ResponseEntity.ok(jugadores);
    }

    @GetMapping("/{id}")
    public ResponseEntity<JugadorConEquipoDto> getJugador(@PathVariable Long id) {
        var jugador = jugadorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Jugador no encontrado"));

        JugadorConEquipoDto dto = new JugadorConEquipoDto(
                jugador.getNombre_jugador(),
                jugador.getApellido(),
                jugador.getNacionalidad(),
                jugador.getAltura(),
                jugador.getPeso(),
                jugador.getValor_mercado(),
                jugador.getF_nacimiento(),
                jugador.getPosicion(),
                jugador.getSueldo(),
                jugador.getEquipo() != null ? jugador.getEquipo().getNombre_equipo() : "Sin equipo",
                "/jugadores/" + jugador.getId_jugador() + "/imagen"
        );
        return ResponseEntity.ok(dto);
    }



}
