
import React from 'react';
import { PitchIcon } from './Icons';

const CreateXI: React.FC = () => {
  return (
    <div className="bg-[#2d2d2d] rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0 md:space-x-6">
      <div className="text-center md:text-left">
        <h2 className="text-xl font-bold mb-2">Creá tu XI ideal</h2>
        <p className="text-gray-400">Prueba nuestro creador de alineaciones.</p>
        <button className="mt-4 bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-lg transition duration-300">
          Comenzar
        </button>
      </div>
      <PitchIcon />
    </div>
  );
};

export default CreateXI;
