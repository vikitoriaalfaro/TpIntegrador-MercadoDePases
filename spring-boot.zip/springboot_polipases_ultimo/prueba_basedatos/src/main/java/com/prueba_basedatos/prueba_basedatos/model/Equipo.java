package com.prueba_basedatos.prueba_basedatos.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "Equipo")
public class Equipo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_equipo;

    private String nombre_equipo;

    private byte[] escudo;

    @ManyToOne
    @JoinColumn(name = "liga_idliga", referencedColumnName = "id_liga")
    private Liga liga;

    @OneToMany(mappedBy = "equipo", cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<Jugador> jugadores;

    private String estadio;

    // Getters y setters
    public Long getId_equipo() { return id_equipo; }
    public void setId_equipo(Long id_equipo) { this.id_equipo = id_equipo; }

    public String getNombre_equipo() { return nombre_equipo; }
    public void setNombre_equipo(String nombre_equipo) { this.nombre_equipo = nombre_equipo; }

    public byte[] getEscudo() { return escudo; }
    public void setEscudo(byte[] escudo) { this.escudo = escudo; }

    public Liga getLiga() { return liga; }
    public void setLiga(Liga liga) { this.liga = liga; }

    public String getEstadio() {
        return estadio;
    }

    public void setEstadio(String estadio) {
        this.estadio = estadio;
    }

    public List<Jugador> getJugadores() {
        return jugadores;
    }

    public void setJugadores(List<Jugador> jugadores) {
        this.jugadores = jugadores;
    }
}
