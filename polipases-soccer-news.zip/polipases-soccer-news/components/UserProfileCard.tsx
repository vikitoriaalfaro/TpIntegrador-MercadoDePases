import React from 'react';
import { StarIcon } from './Icons';
import type { ApiUser } from '../types';

interface UserProfileCardProps {
  user: ApiUser;
}

const SnoopyAvatar: React.FC<{ avatarUrl?: string }> = ({ avatarUrl }) => (
  <div className="w-32 h-32 rounded-full bg-white border-4 border-[#1a1a1a] flex items-center justify-center overflow-hidden">
     <div 
        className="w-full h-full bg-cover bg-center" 
        style={{backgroundImage: `url(${avatarUrl || 'https://api.iconify.design/logos/snoopy.svg'})`}}
      ></div>
  </div>
);


const UserProfileCard: React.FC<UserProfileCardProps> = ({ user }) => {
  // CORRECTED: Added the /api prefix. The DTO returns a relative path like "/usuarios/1/imagen",
  // so we must prepend the base URL and the context path to form a valid URL.
  const avatarUrl = user.foto_usuario_url ? `http://localhost:8080/api${user.foto_usuario_url}` : undefined;

  return (
    <div className="bg-[#1a1a1a] rounded-2xl shadow-lg overflow-hidden">
      <div className="relative h-28 bg-[#1a1a1a]">
        <svg
          className="absolute bottom-0 w-full"
          viewBox="0 0 1440 90"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          preserveAspectRatio="none"
        >
          <path
            d="M-22 89.5C201.5 89.5 288 -21 520 23.5C752 68 893 89.5 1097.5 89.5C1302 89.5 1419 23.5 1419 23.5L1441 89.5H-22Z"
            fill="#1DB954"
          />
        </svg>
        <div className="absolute top-1/2 left-12 transform -translate-y-1/3">
          <SnoopyAvatar avatarUrl={avatarUrl} />
        </div>
      </div>

      <div className="pt-4 pb-6 px-8">
        <div className="flex justify-between items-start">
          <div className="pl-40">
            <h1 className="text-2xl font-bold">{user.nombre_usuario}</h1>
            <p className="text-sm text-gray-400">#{user.usuario_id}</p>
            <div className="flex items-center space-x-4 mt-2 text-sm">
              <div className="flex items-center space-x-1">
                <StarIcon />
                <span>{user.puntos.toLocaleString('es-ES')}</span>
              </div>
            </div>
            <button className="mt-4 bg-black text-white text-sm font-semibold py-2 px-6 rounded-full hover:bg-gray-800 transition">
              Salir
            </button>
          </div>

          <div className="bg-[#2d2d2d] rounded-xl p-4 text-sm w-64">
            <h3 className="font-bold text-white">Información de tu cuenta</h3>
            <p className="text-xs text-gray-400">(Solo tu puedes verlo)</p>
            <div className="mt-3 space-y-2">
              <div>
                <span className="text-gray-400">mail: </span>
                <span className="text-white">{user.mail}</span>
              </div>
              <div>
                <span className="text-gray-400">contraseña: </span>
                <span className="text-white">********</span>
              </div>
            </div>
            <button className="mt-3 w-full bg-black text-white text-sm font-semibold py-2 rounded-lg hover:bg-gray-800 transition">
              Editar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfileCard;